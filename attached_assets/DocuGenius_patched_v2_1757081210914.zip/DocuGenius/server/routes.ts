import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { getWAClient } from "./integrations/whatsapp/factory";
import { getPriceBySku, searchProducts, appendRow } from "./integrations/google/sheets";
import { generateQrPngBuffer } from "./services/qr";
import { telegramBotService } from "./services/telegramBot";
import { documentGenerator } from "./services/documentGenerator";
import { googleDriveService } from "./services/googleDriveService";
import { insertUserSchema, insertTemplateSchema, insertCounterpartySchema, insertBusinessSectorSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Initialize Telegram bot
  await telegramBotService.initialize();

  // Dashboard stats
  app.get("/api/dashboard/stats", async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      const documents = await storage.getRecentDocuments();
      const templates = await storage.getAllTemplates();
      const botStats = await telegramBotService.getStats();

      res.json({
        activeUsers: users.filter(u => u.isActive).length,
        documentsCreated: documents.length,
        templates: templates.filter(t => t.isActive).length,
        aiSuccessRate: 94.2, // Mock value - would be calculated from actual data
        botActive: botStats.botActive
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch dashboard stats" });
    }
  });

  // Recent documents
  app.get("/api/dashboard/recent-documents", async (req, res) => {
    try {
      const documents = await storage.getRecentDocuments(5);
      const enrichedDocuments = await Promise.all(
        documents.map(async (doc) => {
          const user = await storage.getUser(doc.userId);
          const counterparty = await storage.getCounterparty(doc.counterpartyId);
          
          return {
            ...doc,
            userName: user ? `${user.firstName} ${user.lastName}`.trim() : user?.username,
            counterpartyName: counterparty?.name,
            timeAgo: this.getTimeAgo(doc.createdAt)
          };
        })
      );
      
      res.json(enrichedDocuments);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch recent documents" });
    }
  });

  // Users management
  app.get("/api/users", async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      res.json(users);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch users" });
    }
  });

  app.post("/api/users", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const user = await storage.createUser(userData);
      res.status(201).json(user);
    } catch (error) {
      res.status(400).json({ error: "Invalid user data" });
    }
  });

  app.patch("/api/users/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const userData = req.body;
      const user = await storage.updateUser(id, userData);
      
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      
      res.json(user);
    } catch (error) {
      res.status(400).json({ error: "Failed to update user" });
    }
  });

  app.delete("/api/users/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const success = await storage.deleteUser(id);
      
      if (!success) {
        return res.status(404).json({ error: "User not found" });
      }
      
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete user" });
    }
  });

  // Templates management
  app.get("/api/templates", async (req, res) => {
    try {
      const templates = await storage.getAllTemplates();
      res.json(templates);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch templates" });
    }
  });

  app.post("/api/templates", async (req, res) => {
    try {
      const templateData = insertTemplateSchema.parse(req.body);
      const template = await storage.createTemplate(templateData);
      res.status(201).json(template);
    } catch (error) {
      res.status(400).json({ error: "Invalid template data" });
    }
  });

  app.patch("/api/templates/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const templateData = req.body;
      const template = await storage.updateTemplate(id, templateData);
      
      if (!template) {
        return res.status(404).json({ error: "Template not found" });
      }
      
      res.json(template);
    } catch (error) {
      res.status(400).json({ error: "Failed to update template" });
    }
  });

  app.delete("/api/templates/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const success = await storage.deleteTemplate(id);
      
      if (!success) {
        return res.status(404).json({ error: "Template not found" });
      }
      
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete template" });
    }
  });

  // Counterparties management
  app.get("/api/counterparties", async (req, res) => {
    try {
      const { userId } = req.query;
      let counterparties;
      
      if (userId) {
        counterparties = await storage.getCounterpartiesByUserId(userId as string);
      } else {
        // For admin panel - get all counterparties
        const allCounterparties = await storage.getAllUsers(); // This would need a getAllCounterparties method
        counterparties = []; // Simplified for now
      }
      
      res.json(counterparties);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch counterparties" });
    }
  });

  app.post("/api/counterparties", async (req, res) => {
    try {
      const counterpartyData = insertCounterpartySchema.parse(req.body);
      const counterparty = await storage.createCounterparty(counterpartyData);
      res.status(201).json(counterparty);
    } catch (error) {
      res.status(400).json({ error: "Invalid counterparty data" });
    }
  });

  // Business sectors management
  app.get("/api/business-sectors", async (req, res) => {
    try {
      const sectors = await storage.getAllBusinessSectors();
      res.json(sectors);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch business sectors" });
    }
  });

  app.post("/api/business-sectors", async (req, res) => {
    try {
      const sectorData = insertBusinessSectorSchema.parse(req.body);
      const sector = await storage.createBusinessSector(sectorData);
      res.status(201).json(sector);
    } catch (error) {
      res.status(400).json({ error: "Invalid business sector data" });
    }
  });

  app.patch("/api/business-sectors/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const sectorData = req.body;
      const sector = await storage.updateBusinessSector(id, sectorData);
      
      if (!sector) {
        return res.status(404).json({ error: "Business sector not found" });
      }
      
      res.json(sector);
    } catch (error) {
      res.status(400).json({ error: "Failed to update business sector" });
    }
  });

  // Documents management
  app.get("/api/documents", async (req, res) => {
    try {
      const { userId } = req.query;
      let documents;
      
      if (userId) {
        documents = await storage.getDocumentsByUserId(userId as string);
      } else {
        documents = await storage.getRecentDocuments(50);
      }
      
      res.json(documents);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch documents" });
    }
  });

  // Google Drive integration
  app.get("/api/google-drive/status", async (req, res) => {
    try {
      const status = await googleDriveService.getApiStatus();
      res.json(status);
    } catch (error) {
      res.status(500).json({ error: "Failed to check Google Drive status" });
    }
  });

  app.get("/api/google-drive/folders/:userId", async (req, res) => {
    try {
      const { userId } = req.params;
      const folderStructure = await googleDriveService.getFolderStructure(userId);
      res.json(folderStructure);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch folder structure" });
    }
  });

  // System status
  app.get("/api/system/status", async (req, res) => {
    try {
      const telegramStatus = telegramBotService.isActive();
      const googleDriveStatus = await googleDriveService.getApiStatus();
      
      res.json({
        telegram: {
          status: telegramStatus ? 'operational' : 'error',
          message: telegramStatus ? 'Работает нормально' : 'Не подключен'
        },
        googleDrive: googleDriveStatus,
        googleDocs: {
          status: 'warning',
          message: 'Временные сбои'
        }
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch system status" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;

// === AI Assist MVP routes (catalog/pricing/leads/wa/qr) ===
  app.get("/api/catalog/price/:sku", async (req, res) => {
    try {
      const sheetId = process.env.PRICES_SHEET_ID as string;
      const range = process.env.PRICES_RANGE || "Sheet1!A:Z";
      if (!sheetId) return res.status(400).json({ error: "PRICES_SHEET_ID not set" });
      const item = await getPriceBySku(sheetId, range, req.params.sku);
      if (!item) return res.status(404).json({ error: "SKU not found" });
      res.json(item);
    } catch (e: any) {
      res.status(500).json({ error: e.message || "Failed" });
    }
  });

  app.get("/api/catalog/search", async (req, res) => {
    try {
      const q = String(req.query.q || "");
      const sheetId = process.env.PRICES_SHEET_ID as string;
      const range = process.env.PRICES_RANGE || "Sheet1!A:Z";
      if (!sheetId) return res.status(400).json({ error: "PRICES_SHEET_ID not set" });
      const items = await searchProducts(sheetId, range, q);
      res.json(items);
    } catch (e: any) {
      res.status(500).json({ error: e.message || "Failed" });
    }
  });

  app.post("/api/leads", async (req, res) => {
    try {
      const { channel, name, phone, items, sum } = req.body || {};
      const leadId = "ld_" + Date.now();
      const leadsSheetId = process.env.LEADS_SHEET_ID;
      const leadsRange = process.env.LEADS_RANGE || "Sheet1!A:Z";
      if (leadsSheetId) {
        await appendRow(
          leadsSheetId, leadsRange,
          [leadId, channel || 'tg', name || '', phone || '', JSON.stringify(items||[]), sum || 0, "NEW", new Date().toISOString()]
        );
      }
      const qr = await generateQrPngBuffer(`pay://${leadId}`);
      res.setHeader("Content-Type", "image/png");
      res.send(qr);
    } catch (e: any) {
      res.status(500).json({ error: e.message || "Failed" });
    }
  });

  app.post("/api/payments/qr/callback", async (req, res) => {
    const sig = req.header("x-signature");
    if (!sig || sig !== process.env.PAYMENT_CALLBACK_SECRET) return res.status(403).json({ error: "bad signature" });
    // TODO: mark lead as PAID in Google Sheets by LeadID
    res.json({ ok: true });
  });

  
app.post("/api/whatsapp/webhook", async (req, res) => {
  try {
    const body = req.body || {};
    // 360dialog typical payload: { contacts: [...], messages: [{ from, text: { body } }] }
    const msg = (body.messages && body.messages[0]) || null;
    if (!msg) return res.json({ ok: true });
    const from = msg.from || (msg.sender && msg.sender.id);
    let text = '';
    if (msg.text && msg.text.body) text = msg.text.body;
    else if (msg.button && msg.button.text) text = msg.button.text;
    else if (msg.interactive && msg.interactive.button_reply && msg.interactive.button_reply.title) text = msg.interactive.button_reply.title;
    if (!from) return res.json({ ok: true });

    const wa = getWAClient();

    // Commands
    const lower = String(text || '').trim().toLowerCase();
    const sheetId = process.env.PRICES_SHEET_ID as string;
    const range = process.env.PRICES_RANGE || 'Sheet1!A:Z';

    if (lower.startsWith('/price')) {
      const parts = lower.split(' ').filter(Boolean);
      const sku = parts[1];
      if (!sku) {
        await wa.sendText(from, 'Укажите SKU: /price <sku>');
      } else {
        const item = await getPriceBySku(sheetId, range, sku);
        if (!item) await wa.sendText(from, 'Не нашел такой SKU');
        else await wa.sendText(from, `${item.Name} — ${item.Price} ${item.Currency || ''} (SKU ${item.SKU})`);
      }
      return res.json({ ok: true });
    }

    if (lower.startsWith('/find')) {
      const q = lower.replace('/find', '').trim();
      const items = await searchProducts(sheetId, range, q);
      if (!items.length) await wa.sendText(from, 'Ничего не найдено');
      else {
        const top = items.slice(0,5).map(i => `• ${i.Name} — ${i.Price} ${i.Currency || ''} (SKU ${i.SKU})`).join('
');
        await wa.sendText(from, top);
      }
      return res.json({ ok: true });
    }

    if (lower.startsWith('/order')) {
      const leadsSheetId = process.env.LEADS_SHEET_ID;
      const leadsRange = process.env.LEADS_RANGE || 'Sheet1!A:Z';
      const leadId = 'ld_' + Date.now();
      if (leadsSheetId) {
        await appendRow(leadsSheetId, leadsRange, [leadId, 'wa', from, '', '[]', 0, 'NEW', new Date().toISOString()]);
      }
      await wa.sendText(from, 'Заявка создана. Мы пришлём ссылку/QR для оплаты.');
      return res.json({ ok: true });
    }

    // 2GIS and callback keywords
    if (lower.includes('2gis') || lower.includes('навигац')) {
      const url = process.env.TWO_GIS_URL || 'https://2gis.kz';
      await wa.sendText(from, url);
      return res.json({ ok: true });
    }
    if (lower.includes('перезвон')) {
      const cbSheetId = process.env.CALLBACKS_SHEET_ID || process.env.LEADS_SHEET_ID;
      const cbRange = process.env.CALLBACKS_RANGE || process.env.LEADS_RANGE || 'Sheet1!A:Z';
      if (cbSheetId) {
        await appendRow(cbSheetId, cbRange, ['cb_' + Date.now(), 'wa', from, '', 'CALLBACK', new Date().toISOString()]);
      }
      await wa.sendText(from, 'Принято. Менеджер перезвонит.');
      return res.json({ ok: true });
    }

    // Funnel fallback (shared orchestrator)
    const { funnelService } = await import("./services/funnel");
    const { detectLang } = await import("./services/langDetect");
    if (!funnelService.has(from)) {
      const first = funnelService.start(from, detectLang(text) as any);
      await wa.sendText(from, first);
    } else {
      const reply = funnelService.next(from, text);
      if (reply) await wa.sendText(from, reply);
    }
    return res.json({ ok: true });
  } catch (e: any) {
    console.error('WA webhook error', e);
    return res.status(200).json({ ok: true }); // don't retry storms on provider
  }
});
  });
// === End of AI Assist MVP routes ===
}

function getTimeAgo(date: Date): string {
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffMins = Math.floor(diffMs / (1000 * 60));
  
  if (diffMins < 1) return 'только что';
  if (diffMins < 60) return `${diffMins} мин назад`;
  
  const diffHours = Math.floor(diffMins / 60);
  if (diffHours < 24) return `${diffHours} час${diffHours > 1 ? 'а' : ''} назад`;
  
  const diffDays = Math.floor(diffHours / 24);
  return `${diffDays} дн${diffDays > 1 ? 'я' : 'ь'} назад`;
}
