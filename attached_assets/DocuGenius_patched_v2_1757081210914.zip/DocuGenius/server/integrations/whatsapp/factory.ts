import { WAClient } from './base';
import { WA360Client } from './wa360dialog';

export function getWAClient(): WAClient {
  const prov = (process.env.WA_PROVIDER || '360dialog').toLowerCase();
  switch (prov) {
    case '360dialog': return new WA360Client();
    default: throw new Error('Unknown WA provider: ' + prov);
  }
}
