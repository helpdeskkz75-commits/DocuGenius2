import { 
  type User, type InsertUser,
  type Template, type InsertTemplate,
  type Counterparty, type InsertCounterparty,
  type Document, type InsertDocument,
  type BusinessSector, type InsertBusinessSector,
  type BotSession, type InsertBotSession,
  type SystemSettings, type InsertSystemSettings
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByTelegramId(telegramId: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, user: Partial<User>): Promise<User | undefined>;
  getAllUsers(): Promise<User[]>;
  deleteUser(id: string): Promise<boolean>;

  // Templates
  getTemplate(id: string): Promise<Template | undefined>;
  getAllTemplates(): Promise<Template[]>;
  getTemplatesBySector(sector: string): Promise<Template[]>;
  createTemplate(template: InsertTemplate): Promise<Template>;
  updateTemplate(id: string, template: Partial<Template>): Promise<Template | undefined>;
  deleteTemplate(id: string): Promise<boolean>;

  // Counterparties
  getCounterparty(id: string): Promise<Counterparty | undefined>;
  getCounterpartiesByUserId(userId: string): Promise<Counterparty[]>;
  createCounterparty(counterparty: InsertCounterparty): Promise<Counterparty>;
  updateCounterparty(id: string, counterparty: Partial<Counterparty>): Promise<Counterparty | undefined>;
  deleteCounterparty(id: string): Promise<boolean>;

  // Documents
  getDocument(id: string): Promise<Document | undefined>;
  getDocumentsByUserId(userId: string): Promise<Document[]>;
  getRecentDocuments(limit?: number): Promise<Document[]>;
  createDocument(document: InsertDocument): Promise<Document>;
  updateDocument(id: string, document: Partial<Document>): Promise<Document | undefined>;
  deleteDocument(id: string): Promise<boolean>;

  // Business Sectors
  getBusinessSector(id: string): Promise<BusinessSector | undefined>;
  getAllBusinessSectors(): Promise<BusinessSector[]>;
  createBusinessSector(sector: InsertBusinessSector): Promise<BusinessSector>;
  updateBusinessSector(id: string, sector: Partial<BusinessSector>): Promise<BusinessSector | undefined>;
  deleteBusinessSector(id: string): Promise<boolean>;

  // Bot Sessions
  getBotSession(telegramId: string): Promise<BotSession | undefined>;
  createOrUpdateBotSession(session: InsertBotSession): Promise<BotSession>;
  deleteBotSession(telegramId: string): Promise<boolean>;

  // System Settings
  getSystemSetting(key: string): Promise<SystemSettings | undefined>;
  getAllSystemSettings(): Promise<SystemSettings[]>;
  createOrUpdateSystemSetting(setting: InsertSystemSettings): Promise<SystemSettings>;
  deleteSystemSetting(key: string): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private templates: Map<string, Template>;
  private counterparties: Map<string, Counterparty>;
  private documents: Map<string, Document>;
  private businessSectors: Map<string, BusinessSector>;
  private botSessions: Map<string, BotSession>;
  private systemSettings: Map<string, SystemSettings>;

  constructor() {
    this.users = new Map();
    this.templates = new Map();
    this.counterparties = new Map();
    this.documents = new Map();
    this.businessSectors = new Map();
    this.botSessions = new Map();
    this.systemSettings = new Map();

    // Initialize default business sectors
    this.initializeDefaultData();
  }

  private initializeDefaultData() {
    const defaultSectors: InsertBusinessSector[] = [
      { name: "Стоматология", icon: "fa-tooth", isActive: true, userCount: 24 },
      { name: "Ресторанный бизнес", icon: "fa-utensils", isActive: true, userCount: 18 },
      { name: "Строительство", icon: "fa-hammer", isActive: true, userCount: 31 },
      { name: "Юридические услуги", icon: "fa-balance-scale", isActive: true, userCount: 12 },
    ];

    defaultSectors.forEach(sector => {
      const id = randomUUID();
      this.businessSectors.set(id, { ...sector, id, createdAt: new Date() });
    });

    // Initialize default templates
    const defaultTemplates: InsertTemplate[] = [
      {
        name: "Договор оказания стоматологических услуг",
        type: "договор",
        sector: "Стоматология",
        googleDocsId: "mock_template_1",
        placeholders: ["CLIENT_NAME", "SERVICE_TYPE", "COST", "DATE"],
        isActive: true,
      },
      {
        name: "Счет за стоматологические услуги",
        type: "счет",
        sector: "Стоматология",
        googleDocsId: "mock_template_2",
        placeholders: ["CLIENT_NAME", "SERVICE_TYPE", "COST", "DATE", "INVOICE_NUMBER"],
        isActive: true,
      },
    ];

    defaultTemplates.forEach(template => {
      const id = randomUUID();
      this.templates.set(id, { ...template, id, createdAt: new Date() });
    });
  }

  // Users
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByTelegramId(telegramId: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.telegramId === telegramId);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { 
      ...insertUser, 
      id, 
      createdAt: new Date(),
      isActive: true 
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: string, userData: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    const updatedUser = { ...user, ...userData };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async getAllUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  async deleteUser(id: string): Promise<boolean> {
    return this.users.delete(id);
  }

  // Templates
  async getTemplate(id: string): Promise<Template | undefined> {
    return this.templates.get(id);
  }

  async getAllTemplates(): Promise<Template[]> {
    return Array.from(this.templates.values());
  }

  async getTemplatesBySector(sector: string): Promise<Template[]> {
    return Array.from(this.templates.values()).filter(template => template.sector === sector);
  }

  async createTemplate(insertTemplate: InsertTemplate): Promise<Template> {
    const id = randomUUID();
    const template: Template = { 
      ...insertTemplate, 
      id, 
      createdAt: new Date() 
    };
    this.templates.set(id, template);
    return template;
  }

  async updateTemplate(id: string, templateData: Partial<Template>): Promise<Template | undefined> {
    const template = this.templates.get(id);
    if (!template) return undefined;
    const updatedTemplate = { ...template, ...templateData };
    this.templates.set(id, updatedTemplate);
    return updatedTemplate;
  }

  async deleteTemplate(id: string): Promise<boolean> {
    return this.templates.delete(id);
  }

  // Counterparties
  async getCounterparty(id: string): Promise<Counterparty | undefined> {
    return this.counterparties.get(id);
  }

  async getCounterpartiesByUserId(userId: string): Promise<Counterparty[]> {
    return Array.from(this.counterparties.values()).filter(cp => cp.userId === userId);
  }

  async createCounterparty(insertCounterparty: InsertCounterparty): Promise<Counterparty> {
    const id = randomUUID();
    const counterparty: Counterparty = { 
      ...insertCounterparty, 
      id, 
      createdAt: new Date() 
    };
    this.counterparties.set(id, counterparty);
    return counterparty;
  }

  async updateCounterparty(id: string, counterpartyData: Partial<Counterparty>): Promise<Counterparty | undefined> {
    const counterparty = this.counterparties.get(id);
    if (!counterparty) return undefined;
    const updatedCounterparty = { ...counterparty, ...counterpartyData };
    this.counterparties.set(id, updatedCounterparty);
    return updatedCounterparty;
  }

  async deleteCounterparty(id: string): Promise<boolean> {
    return this.counterparties.delete(id);
  }

  // Documents
  async getDocument(id: string): Promise<Document | undefined> {
    return this.documents.get(id);
  }

  async getDocumentsByUserId(userId: string): Promise<Document[]> {
    return Array.from(this.documents.values()).filter(doc => doc.userId === userId);
  }

  async getRecentDocuments(limit: number = 10): Promise<Document[]> {
    return Array.from(this.documents.values())
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
      .slice(0, limit);
  }

  async createDocument(insertDocument: InsertDocument): Promise<Document> {
    const id = randomUUID();
    const document: Document = { 
      ...insertDocument, 
      id, 
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.documents.set(id, document);
    return document;
  }

  async updateDocument(id: string, documentData: Partial<Document>): Promise<Document | undefined> {
    const document = this.documents.get(id);
    if (!document) return undefined;
    const updatedDocument = { ...document, ...documentData, updatedAt: new Date() };
    this.documents.set(id, updatedDocument);
    return updatedDocument;
  }

  async deleteDocument(id: string): Promise<boolean> {
    return this.documents.delete(id);
  }

  // Business Sectors
  async getBusinessSector(id: string): Promise<BusinessSector | undefined> {
    return this.businessSectors.get(id);
  }

  async getAllBusinessSectors(): Promise<BusinessSector[]> {
    return Array.from(this.businessSectors.values());
  }

  async createBusinessSector(insertSector: InsertBusinessSector): Promise<BusinessSector> {
    const id = randomUUID();
    const sector: BusinessSector = { 
      ...insertSector, 
      id, 
      createdAt: new Date() 
    };
    this.businessSectors.set(id, sector);
    return sector;
  }

  async updateBusinessSector(id: string, sectorData: Partial<BusinessSector>): Promise<BusinessSector | undefined> {
    const sector = this.businessSectors.get(id);
    if (!sector) return undefined;
    const updatedSector = { ...sector, ...sectorData };
    this.businessSectors.set(id, updatedSector);
    return updatedSector;
  }

  async deleteBusinessSector(id: string): Promise<boolean> {
    return this.businessSectors.delete(id);
  }

  // Bot Sessions
  async getBotSession(telegramId: string): Promise<BotSession | undefined> {
    return Array.from(this.botSessions.values()).find(session => session.telegramId === telegramId);
  }

  async createOrUpdateBotSession(sessionData: InsertBotSession): Promise<BotSession> {
    const existingSession = await this.getBotSession(sessionData.telegramId);
    
    if (existingSession) {
      const updatedSession = { 
        ...existingSession, 
        ...sessionData, 
        updatedAt: new Date() 
      };
      this.botSessions.set(existingSession.id, updatedSession);
      return updatedSession;
    } else {
      const id = randomUUID();
      const session: BotSession = { 
        ...sessionData, 
        id, 
        createdAt: new Date(),
        updatedAt: new Date()
      };
      this.botSessions.set(id, session);
      return session;
    }
  }

  async deleteBotSession(telegramId: string): Promise<boolean> {
    const session = await this.getBotSession(telegramId);
    if (!session) return false;
    return this.botSessions.delete(session.id);
  }

  // System Settings
  async getSystemSetting(key: string): Promise<SystemSettings | undefined> {
    return Array.from(this.systemSettings.values()).find(setting => setting.key === key);
  }

  async getAllSystemSettings(): Promise<SystemSettings[]> {
    return Array.from(this.systemSettings.values());
  }

  async createOrUpdateSystemSetting(settingData: InsertSystemSettings): Promise<SystemSettings> {
    const existingSetting = await this.getSystemSetting(settingData.key);
    
    if (existingSetting) {
      const updatedSetting = { 
        ...existingSetting, 
        ...settingData, 
        updatedAt: new Date() 
      };
      this.systemSettings.set(existingSetting.id, updatedSetting);
      return updatedSetting;
    } else {
      const id = randomUUID();
      const setting: SystemSettings = { 
        ...settingData, 
        id, 
        updatedAt: new Date() 
      };
      this.systemSettings.set(id, setting);
      return setting;
    }
  }

  async deleteSystemSetting(key: string): Promise<boolean> {
    const setting = await this.getSystemSetting(key);
    if (!setting) return false;
    return this.systemSettings.delete(setting.id);
  }
}

export const storage = new MemStorage();
