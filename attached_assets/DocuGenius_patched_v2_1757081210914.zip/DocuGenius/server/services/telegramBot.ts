import TelegramBot from 'node-telegram-bot-api';
import { storage } from '../storage';
import { documentGenerator } from './documentGenerator';
import { googleDriveService } from './googleDriveService';
import { getPriceBySku, searchProducts, appendRow } from '../integrations/google/sheets';
import { generateQrPngBuffer } from '../services/qr';
import { funnelService } from '../services/funnel';
import { detectLang } from '../services/langDetect';

class TelegramBotService {
  private bot: TelegramBot | null = null;
  private isInitialized = false;

  async initialize() {
    const token = process.env.TELEGRAM_BOT_TOKEN;
    if (!token) {
      console.error('TELEGRAM_BOT_TOKEN not provided');
      return;
    }

    this.bot = new TelegramBot(token, { polling: true });
    await this.setupCommands();
    await this.setupMessageHandlers();
    this.isInitialized = true;
    console.log('Telegram bot initialized successfully');
  
// === AI Assist MVP commands ===
await this.bot.setMyCommands([
  { command: 'start', description: 'Начать' },
  { command: 'stop', description: 'Передать диалог менеджеру' },
  { command: 'price', description: 'Цена по SKU' },
  { command: 'find', description: 'Поиск товара' },
  { command: 'promo', description: 'Каталог/акции' },
  { command: 'order', description: 'Создать заявку и оплату' }
]);

// stop/hand-over
this.bot.onText(/\/stop/, async (msg) => {
  const chatId = msg.chat.id;
  await this.bot!.sendMessage(chatId, 'Передал диалог менеджеру. Ожидайте, он подключится.');
  const groupId = process.env.TELEGRAM_OPERATORS_GROUP_ID;
  if (groupId) {
    await this.bot!.sendMessage(Number(groupId), `Хэндовер: чат ${chatId} передан менеджеру.`);
  }
});

// price
this.bot.onText(/\/price (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const sku = (match?.[1] || '').trim();
  if (!sku) return this.bot!.sendMessage(chatId, 'Укажите SKU: /price <sku>');
  const sheetId = process.env.PRICES_SHEET_ID as string;
  const range = process.env.PRICES_RANGE || 'Sheet1!A:Z';
  try {
    const item = await getPriceBySku(sheetId, range, sku);
    if (!item) return this.bot!.sendMessage(chatId, 'Не нашел такой SKU');
    let text = `${item.Name} — ${item.Price} ${item.Currency || ''}\nSKU: ${item.SKU}`;
    if (item.PhotoURL) await this.bot!.sendPhoto(chatId, item.PhotoURL, { caption: text });
    else await this.bot!.sendMessage(chatId, text);
  } catch (e:any) {
    await this.bot!.sendMessage(chatId, 'Ошибка при получении цены');
  }
});

// find
this.bot.onText(/\/find (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const q = (match?.[1] || '').trim();
  const sheetId = process.env.PRICES_SHEET_ID as string;
  const range = process.env.PRICES_RANGE || 'Sheet1!A:Z';
  try {
    const items = await searchProducts(sheetId, range, q);
    if (!items.length) return this.bot!.sendMessage(chatId, 'Ничего не найдено');
    const top = items.slice(0,5).map(i => `• ${i.Name} — ${i.Price} ${i.Currency || ''} (SKU ${i.SKU})`).join('\n');
    await this.bot!.sendMessage(chatId, top);
  } catch (e:any) {
    await this.bot!.sendMessage(chatId, 'Ошибка поиска');
  }
});

// promo
this.bot.onText(/\/promo/, async (msg) => {
  const chatId = msg.chat.id;
  const url = process.env.PROMO_URL || 'https://example.com';
  await this.bot!.sendMessage(chatId, 'Каталог и акции:', {
    reply_markup: { inline_keyboard: [[{ text: 'Открыть', url }]] } as any
  });
});

// order -> create lead + QR
this.bot.onText(/\/order/, async (msg) => {
  const chatId = msg.chat.id;
  const leadsSheetId = process.env.LEADS_SHEET_ID;
  const leadsRange = process.env.LEADS_RANGE || 'Sheet1!A:Z';
  const leadId = 'ld_' + Date.now();
  try {
    if (leadsSheetId) {
      await appendRow(leadsSheetId, leadsRange, [leadId, 'tg', msg.from?.username || '', '', '[]', 0, 'NEW', new Date().toISOString()]);
    }
    const png = await generateQrPngBuffer(`pay://${leadId}`);
    await this.bot!.sendPhoto(chatId, png, { caption: 'Отсканируйте QR для оплаты' });
    const groupId = process.env.TELEGRAM_OPERATORS_GROUP_ID;
    if (groupId) await this.bot!.sendMessage(Number(groupId), `Новая заявка ${leadId} из чата ${chatId}`);
  } catch (e:any) {
    await this.bot!.sendMessage(chatId, 'Не удалось создать заявку');
  }
});

// start with keyboard
this.bot.onText(/\/start/, async (msg) => {
  const chatId = msg.chat.id;
  const keyboard = {
    keyboard: [[{ text: '🧭 Навигация (2GIS)' }, { text: '📞 Перезвонить' }]],
    resize_keyboard: true
  };
  await this.bot!.sendMessage(chatId, 'Выберите действие или опишите ваш запрос:', { reply_markup: keyboard as any });
  const first = funnelService.start(chatId, 'ru' as any);
  await this.bot!.sendMessage(chatId, first);
});

// 2GIS + Перезвон (text buttons)
this.bot.on('message', async (msg) => {
  if (!msg.text) return;
  const text = msg.text.trim().toLowerCase();
  const chatId = msg.chat.id;
  if (text.includes('навигац') || text.includes('2gis')) {
    const url = process.env.TWO_GIS_URL || 'https://2gis.kz';
    return this.bot!.sendMessage(chatId, url);
  }
  if (text.includes('перезвон')) {
    const leadsSheetId = process.env.CALLBACKS_SHEET_ID || process.env.LEADS_SHEET_ID;
    const leadsRange = process.env.CALLBACKS_RANGE || process.env.LEADS_RANGE || 'Sheet1!A:Z';
    if (leadsSheetId) {
      await appendRow(leadsSheetId, leadsRange, ['cb_' + Date.now(), 'tg', msg.from?.username || '', msg.contact?.phone_number || '', 'CALLBACK', new Date().toISOString()]);
    }
    const groupId = process.env.TELEGRAM_OPERATORS_GROUP_ID;
    if (groupId) await this.bot!.sendMessage(Number(groupId), `Запрошен перезвон из чата ${chatId}`);
    return this.bot!.sendMessage(chatId, 'Принято. Менеджер скоро перезвонит.');
  }
});

// language + 3-step funnel as fallback
this.bot.on('message', async (msg) => {
  if (!msg.text) return;
  if (msg.text.startsWith('/')) return; // skip commands
  const chatId = msg.chat.id;
  const t = msg.text || '';
  if (!(funnelService as any).sessions?.has(chatId)) {
    const lang = detectLang(t);
    const first = funnelService.start(chatId, lang as any);
    await this.bot!.sendMessage(chatId, first);
  } else {
    const reply = funnelService.next(chatId, t);
    if (reply) await this.bot!.sendMessage(chatId, reply);
  }
});
// === End of AI Assist MVP commands ===

}

  private async setupCommands() {
    if (!this.bot) return;

    await this.bot.setMyCommands([
      { command: 'start', description: 'Начать работу с ботом' },
      { command: 'register', description: 'Зарегистрироваться в системе' },
      { command: 'create_contract', description: 'Создать договор' },
      { command: 'create_invoice', description: 'Создать счет' },
      { command: 'create_act', description: 'Создать акт выполненных работ' },
      { command: 'my_documents', description: 'Мои документы' },
      { command: 'help', description: 'Помощь' },
    ]);
  }

  private async setupMessageHandlers() {
    if (!this.bot) return;

    // Start command
    this.bot.onText(/\/start/, async (msg) => {
      const chatId = msg.chat.id;
      const telegramId = msg.from?.id.toString();
      
      if (!telegramId) return;

      const user = await storage.getUserByTelegramId(telegramId);
      
      if (user) {
        await this.bot!.sendMessage(chatId, 
          `Добро пожаловать обратно, ${user.firstName || user.username}! 
          
Используйте команды для создания документов:
/create_contract - Создать договор
/create_invoice - Создать счет  
/create_act - Создать акт выполненных работ
/my_documents - Просмотр документов`
        );
      } else {
        await this.bot!.sendMessage(chatId, 
          `Добро пожаловать в DocuBot! 

Для начала работы необходимо зарегистрироваться.
Используйте команду /register`
        );
      }
    });

    // Register command
    this.bot.onText(/\/register/, async (msg) => {
      await this.handleRegistration(msg);
    });

    // Create contract command
    this.bot.onText(/\/create_contract/, async (msg) => {
      await this.handleDocumentCreation(msg, 'договор');
    });

    // Create invoice command
    this.bot.onText(/\/create_invoice/, async (msg) => {
      await this.handleDocumentCreation(msg, 'счет');
    });

    // Create act command
    this.bot.onText(/\/create_act/, async (msg) => {
      await this.handleDocumentCreation(msg, 'акт');
    });

    // My documents command
    this.bot.onText(/\/my_documents/, async (msg) => {
      await this.handleMyDocuments(msg);
    });

    // Handle text messages for conversation flows
    this.bot.on('message', async (msg) => {
      if (msg.text?.startsWith('/')) return; // Skip commands
      await this.handleConversationFlow(msg);
    });
  }

  private async handleRegistration(msg: TelegramBot.Message) {
    const chatId = msg.chat.id;
    const telegramId = msg.from?.id.toString();
    const username = msg.from?.username || '';
    const firstName = msg.from?.first_name || '';
    const lastName = msg.from?.last_name || '';

    if (!telegramId) return;

    const existingUser = await storage.getUserByTelegramId(telegramId);
    if (existingUser) {
      await this.bot!.sendMessage(chatId, 'Вы уже зарегистрированы в системе!');
      return;
    }

    // Start registration flow
    await storage.createOrUpdateBotSession({
      telegramId,
      state: 'awaiting_business_type',
      data: { username, firstName, lastName }
    });

    const keyboard = {
      reply_markup: {
        inline_keyboard: [
          [{ text: 'ИП (Индивидуальный предприниматель)', callback_data: 'business_type_ip' }],
          [{ text: 'ТОО (Товарищество с ограниченной ответственностью)', callback_data: 'business_type_too' }]
        ]
      }
    };

    await this.bot!.sendMessage(chatId, 
      'Выберите тип вашего бизнеса:', 
      keyboard
    );
  }

  private async handleDocumentCreation(msg: TelegramBot.Message, documentType: string) {
    const chatId = msg.chat.id;
    const telegramId = msg.from?.id.toString();

    if (!telegramId) return;

    const user = await storage.getUserByTelegramId(telegramId);
    if (!user) {
      await this.bot!.sendMessage(chatId, 'Для создания документов необходимо зарегистрироваться. Используйте /register');
      return;
    }

    // Get available templates for user's sector
    const templates = await storage.getTemplatesBySector(user.sector || 'Общая');
    const relevantTemplates = templates.filter(t => t.type === documentType && t.isActive);

    if (relevantTemplates.length === 0) {
      await this.bot!.sendMessage(chatId, `Шаблоны для типа "${documentType}" в вашей отрасли пока не настроены.`);
      return;
    }

    // Start document creation flow
    await storage.createOrUpdateBotSession({
      telegramId,
      state: 'selecting_template',
      data: { documentType, templates: relevantTemplates.map(t => ({ id: t.id, name: t.name })) }
    });

    const keyboard = {
      reply_markup: {
        inline_keyboard: relevantTemplates.map(template => [
          { text: template.name, callback_data: `select_template_${template.id}` }
        ])
      }
    };

    await this.bot!.sendMessage(chatId, 'Выберите шаблон документа:', keyboard);
  }

  private async handleMyDocuments(msg: TelegramBot.Message) {
    const chatId = msg.chat.id;
    const telegramId = msg.from?.id.toString();

    if (!telegramId) return;

    const user = await storage.getUserByTelegramId(telegramId);
    if (!user) {
      await this.bot!.sendMessage(chatId, 'Для просмотра документов необходимо зарегистрироваться. Используйте /register');
      return;
    }

    const documents = await storage.getDocumentsByUserId(user.id);
    
    if (documents.length === 0) {
      await this.bot!.sendMessage(chatId, 'У вас пока нет созданных документов.');
      return;
    }

    let message = 'Ваши документы:\n\n';
    documents.slice(0, 10).forEach((doc, index) => {
      const statusIcon = doc.status === 'generated' ? '✅' : doc.status === 'sent' ? '📤' : '📝';
      message += `${index + 1}. ${statusIcon} ${doc.name}\n`;
      message += `   Статус: ${doc.status}\n`;
      message += `   Создан: ${doc.createdAt.toLocaleDateString('ru-RU')}\n\n`;
    });

    await this.bot!.sendMessage(chatId, message);
  }

  private async handleConversationFlow(msg: TelegramBot.Message) {
    const chatId = msg.chat.id;
    const telegramId = msg.from?.id.toString();
    const messageText = msg.text;

    if (!telegramId || !messageText) return;

    const session = await storage.getBotSession(telegramId);
    if (!session) return;

    switch (session.state) {
      case 'awaiting_business_name':
        await this.handleBusinessNameInput(chatId, telegramId, messageText, session);
        break;
      case 'awaiting_counterparty_name':
        await this.handleCounterpartyNameInput(chatId, telegramId, messageText, session);
        break;
      case 'awaiting_placeholder_values':
        await this.handlePlaceholderInput(chatId, telegramId, messageText, session);
        break;
    }
  }

  private async handleBusinessNameInput(chatId: number, telegramId: string, businessName: string, session: any) {
    // Create user with business information
    const userData = {
      ...session.data,
      businessName,
      telegramId
    };

    // Show sector selection
    const sectors = await storage.getAllBusinessSectors();
    const keyboard = {
      reply_markup: {
        inline_keyboard: sectors.map(sector => [
          { text: sector.name, callback_data: `select_sector_${sector.id}` }
        ])
      }
    };

    await storage.createOrUpdateBotSession({
      telegramId,
      state: 'selecting_sector',
      data: userData
    });

    await this.bot!.sendMessage(chatId, 'Выберите вашу отрасль:', keyboard);
  }

  private async handleCounterpartyNameInput(chatId: number, telegramId: string, counterpartyName: string, session: any) {
    // This would handle counterparty creation flow
    await this.bot!.sendMessage(chatId, `Контрагент "${counterpartyName}" добавлен. Теперь можете создавать документы!`);
    await storage.deleteBotSession(telegramId);
  }

  private async handlePlaceholderInput(chatId: number, telegramId: string, input: string, session: any) {
    // This would handle placeholder value collection for document generation
    await this.bot!.sendMessage(chatId, 'Документ создается...');
    await storage.deleteBotSession(telegramId);
  }

  async handleCallbackQuery(callbackQuery: TelegramBot.CallbackQuery) {
    if (!this.bot || !callbackQuery.data) return;

    const chatId = callbackQuery.message?.chat.id;
    const telegramId = callbackQuery.from.id.toString();
    const data = callbackQuery.data;

    if (!chatId) return;

    if (data.startsWith('business_type_')) {
      const businessType = data.replace('business_type_', '').toUpperCase();
      const session = await storage.getBotSession(telegramId);
      
      if (session) {
        await storage.createOrUpdateBotSession({
          telegramId,
          state: 'awaiting_business_name',
          data: { ...session.data, businessType }
        });

        await this.bot.sendMessage(chatId, `Введите название вашего ${businessType === 'IP' ? 'ИП' : 'ТОО'}:`);
      }
    } else if (data.startsWith('select_sector_')) {
      const sectorId = data.replace('select_sector_', '');
      const sector = await storage.getBusinessSector(sectorId);
      const session = await storage.getBotSession(telegramId);

      if (sector && session) {
        // Create the user
        const newUser = await storage.createUser({
          ...session.data,
          sector: sector.name
        });

        await this.bot.sendMessage(chatId, 
          `Регистрация завершена! Добро пожаловать, ${newUser.firstName || newUser.username}!
          
Теперь вы можете создавать документы:
/create_contract - Создать договор
/create_invoice - Создать счет
/create_act - Создать акт выполненных работ`
        );

        await storage.deleteBotSession(telegramId);
      }
    } else if (data.startsWith('select_template_')) {
      const templateId = data.replace('select_template_', '');
      const template = await storage.getTemplate(templateId);
      const user = await storage.getUserByTelegramId(telegramId);

      if (template && user) {
        await this.bot.sendMessage(chatId, 
          `Шаблон "${template.name}" выбран. Для создания документа потребуется информация о контрагенте.
          
Введите название контрагента:`
        );

        await storage.createOrUpdateBotSession({
          telegramId,
          state: 'awaiting_counterparty_name',
          data: { templateId, userId: user.id }
        });
      }
    }

    await this.bot.answerCallbackQuery(callbackQuery.id);
  }

  isActive(): boolean {
    return this.isInitialized && this.bot !== null;
  }

  async getStats() {
    const users = await storage.getAllUsers();
    const documents = await storage.getRecentDocuments();
    
    return {
      activeUsers: users.filter(u => u.isActive).length,
      totalDocuments: documents.length,
      botActive: this.isActive()
    };
  }
}

export const telegramBotService = new TelegramBotService();
