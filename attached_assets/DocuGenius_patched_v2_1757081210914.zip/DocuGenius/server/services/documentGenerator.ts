import { storage } from '../storage';
import { googleDriveService } from './googleDriveService';
import type { Template, User, Counterparty } from '@shared/schema';

interface DocumentGenerationRequest {
  userId: string;
  templateId: string;
  counterpartyId: string;
  placeholderValues: Record<string, string>;
}

class DocumentGenerator {
  async generateDocument(request: DocumentGenerationRequest) {
    const { userId, templateId, counterpartyId, placeholderValues } = request;

    // Get required data
    const user = await storage.getUser(userId);
    const template = await storage.getTemplate(templateId);
    const counterparty = await storage.getCounterparty(counterpartyId);

    if (!user || !template || !counterparty) {
      throw new Error('Invalid request: missing user, template, or counterparty');
    }

    // Create document record
    const document = await storage.createDocument({
      userId,
      templateId,
      counterpartyId,
      name: `${template.name} - ${counterparty.name}`,
      status: 'draft',
      placeholderValues
    });

    try {
      // Generate document content
      const content = await this.processTemplate(template, placeholderValues, user, counterparty);
      
      // Save to Google Drive
      const driveResult = await googleDriveService.createDocument({
        name: document.name,
        content,
        folderPath: `/${user.businessName}/${counterparty.name}/Договоры`
      });

      // Update document with Google Drive info
      const updatedDocument = await storage.updateDocument(document.id, {
        status: 'generated',
        googleDriveFileId: driveResult.fileId,
        googleDriveFolderPath: driveResult.folderPath
      });

      return updatedDocument;
    } catch (error) {
      // Update document status to error
      await storage.updateDocument(document.id, {
        status: 'error'
      });
      throw error;
    }
  }

  private async processTemplate(
    template: Template, 
    placeholderValues: Record<string, string>,
    user: User,
    counterparty: Counterparty
  ): string {
    // Mock template processing - in real implementation this would use Google Docs API
    let content = `Шаблон: ${template.name}

Исполнитель: ${user.businessName}
Контрагент: ${counterparty.name}
Тип контрагента: ${counterparty.type}

`;

    // Process placeholders
    Object.entries(placeholderValues).forEach(([key, value]) => {
      content += `${key}: ${value}\n`;
    });

    content += `
Документ создан: ${new Date().toLocaleDateString('ru-RU')}
`;

    return content;
  }

  async getDocumentById(documentId: string) {
    return await storage.getDocument(documentId);
  }

  async getDocumentsByUser(userId: string) {
    return await storage.getDocumentsByUserId(userId);
  }
}

export const documentGenerator = new DocumentGenerator();
