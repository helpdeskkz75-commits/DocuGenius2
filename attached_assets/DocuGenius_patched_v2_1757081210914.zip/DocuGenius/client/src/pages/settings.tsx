import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Header } from "@/components/layout/header";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface SystemSetting {
  id: string;
  key: string;
  value: string;
  description: string;
  updatedAt: string;
}

export default function Settings() {
  const [botToken, setBotToken] = useState("");
  const [googleCredentials, setGoogleCredentials] = useState("");
  const [systemMessage, setSystemMessage] = useState("");
  const [enableNotifications, setEnableNotifications] = useState(true);
  const [enableLogging, setEnableLogging] = useState(true);
  const [maxDocumentsPerUser, setMaxDocumentsPerUser] = useState("100");
  const [sessionTimeout, setSessionTimeout] = useState("30");
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: settings = [], isLoading } = useQuery<SystemSetting[]>({
    queryKey: ["/api/system/settings"],
  });

  const updateSettingMutation = useMutation({
    mutationFn: async (settingData: { key: string; value: string; description: string }) => {
      const response = await apiRequest("POST", "/api/system/settings", settingData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/system/settings"] });
      toast({
        title: "Успех",
        description: "Настройки успешно сохранены",
      });
    },
    onError: () => {
      toast({
        title: "Ошибка",
        description: "Не удалось сохранить настройки",
        variant: "destructive",
      });
    },
  });

  const handleSaveBotSettings = () => {
    updateSettingMutation.mutate({
      key: 'TELEGRAM_BOT_TOKEN',
      value: botToken,
      description: 'Токен Telegram бота'
    });
  };

  const handleSaveGoogleSettings = () => {
    updateSettingMutation.mutate({
      key: 'GOOGLE_CREDENTIALS',
      value: googleCredentials,
      description: 'Учетные данные Google API'
    });
  };

  const handleSaveSystemSettings = () => {
    const systemSettings = [
      {
        key: 'SYSTEM_MESSAGE',
        value: systemMessage,
        description: 'Системное сообщение для пользователей'
      },
      {
        key: 'ENABLE_NOTIFICATIONS',
        value: enableNotifications.toString(),
        description: 'Включить уведомления'
      },
      {
        key: 'ENABLE_LOGGING',
        value: enableLogging.toString(),
        description: 'Включить логирование'
      },
      {
        key: 'MAX_DOCUMENTS_PER_USER',
        value: maxDocumentsPerUser,
        description: 'Максимальное количество документов на пользователя'
      },
      {
        key: 'SESSION_TIMEOUT',
        value: sessionTimeout,
        description: 'Время ожидания сессии (минуты)'
      }
    ];

    systemSettings.forEach(setting => {
      updateSettingMutation.mutate(setting);
    });
  };

  const handleExportSettings = () => {
    const settingsData = settings.reduce((acc, setting) => {
      acc[setting.key] = setting.value;
      return acc;
    }, {} as Record<string, string>);

    const blob = new Blob([JSON.stringify(settingsData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'docubot-settings.json';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    toast({
      title: "Экспорт завершен",
      description: "Настройки экспортированы в файл",
    });
  };

  const handleClearCache = () => {
    queryClient.clear();
    toast({
      title: "Кэш очищен",
      description: "Кэш приложения успешно очищен",
    });
  };

  return (
    <div className="flex flex-col h-screen overflow-hidden">
      <Header 
        title="Настройки системы" 
        description="Конфигурация основных параметров системы"
      />

      <main className="flex-1 overflow-y-auto p-6">
        <Tabs defaultValue="bot" className="space-y-6">
          <TabsList>
            <TabsTrigger value="bot" data-testid="tab-bot-settings">Telegram Bot</TabsTrigger>
            <TabsTrigger value="google" data-testid="tab-google-settings">Google API</TabsTrigger>
            <TabsTrigger value="system" data-testid="tab-system-settings">Система</TabsTrigger>
            <TabsTrigger value="backup" data-testid="tab-backup-settings">Резервные копии</TabsTrigger>
          </TabsList>

          <TabsContent value="bot">
            <Card>
              <CardHeader>
                <CardTitle>Настройки Telegram Bot</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <Label htmlFor="botToken">Токен бота</Label>
                  <Input
                    id="botToken"
                    type="password"
                    value={botToken}
                    onChange={(e) => setBotToken(e.target.value)}
                    placeholder="Введите токен Telegram бота"
                    data-testid="input-bot-token"
                  />
                  <p className="text-sm text-muted-foreground mt-2">
                    Получите токен у @BotFather в Telegram
                  </p>
                </div>

                <div className="bg-muted p-4 rounded-lg">
                  <h4 className="font-medium mb-2">Статус бота</h4>
                  <div className="flex items-center space-x-2">
                    <span className="w-2 h-2 bg-accent rounded-full"></span>
                    <span className="text-sm" data-testid="bot-status-text">Бот активен и работает</span>
                  </div>
                </div>

                <div className="space-y-4">
                  <h4 className="font-medium">Доступные команды</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <code>/start</code>
                        <span className="text-muted-foreground">Начать работу</span>
                      </div>
                      <div className="flex justify-between">
                        <code>/register</code>
                        <span className="text-muted-foreground">Регистрация</span>
                      </div>
                      <div className="flex justify-between">
                        <code>/create_contract</code>
                        <span className="text-muted-foreground">Создать договор</span>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <code>/create_invoice</code>
                        <span className="text-muted-foreground">Создать счет</span>
                      </div>
                      <div className="flex justify-between">
                        <code>/create_act</code>
                        <span className="text-muted-foreground">Создать акт</span>
                      </div>
                      <div className="flex justify-between">
                        <code>/my_documents</code>
                        <span className="text-muted-foreground">Мои документы</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex justify-end">
                  <Button 
                    onClick={handleSaveBotSettings}
                    disabled={updateSettingMutation.isPending}
                    data-testid="button-save-bot-settings"
                  >
                    {updateSettingMutation.isPending ? "Сохранение..." : "Сохранить настройки"}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="google">
            <Card>
              <CardHeader>
                <CardTitle>Настройки Google API</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <Label htmlFor="googleCredentials">JSON ключ сервисного аккаунта</Label>
                  <Textarea
                    id="googleCredentials"
                    value={googleCredentials}
                    onChange={(e) => setGoogleCredentials(e.target.value)}
                    placeholder="Вставьте содержимое JSON файла с ключами..."
                    rows={10}
                    data-testid="textarea-google-credentials"
                  />
                  <p className="text-sm text-muted-foreground mt-2">
                    Создайте сервисный аккаунт в Google Cloud Console и скачайте JSON ключ
                  </p>
                </div>

                <div className="bg-muted p-4 rounded-lg">
                  <h4 className="font-medium mb-2">Статус подключения</h4>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Google Drive API</span>
                      <div className="flex items-center space-x-2">
                        <span className="w-2 h-2 bg-accent rounded-full"></span>
                        <span className="text-sm text-accent">Подключено</span>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Google Docs API</span>
                      <div className="flex items-center space-x-2">
                        <span className="w-2 h-2 bg-chart-3 rounded-full"></span>
                        <span className="text-sm text-chart-3">Временные сбои</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex justify-end">
                  <Button 
                    onClick={handleSaveGoogleSettings}
                    disabled={updateSettingMutation.isPending}
                    data-testid="button-save-google-settings"
                  >
                    {updateSettingMutation.isPending ? "Сохранение..." : "Сохранить настройки"}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="system">
            <Card>
              <CardHeader>
                <CardTitle>Системные настройки</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <Label htmlFor="systemMessage">Системное сообщение</Label>
                  <Textarea
                    id="systemMessage"
                    value={systemMessage}
                    onChange={(e) => setSystemMessage(e.target.value)}
                    placeholder="Введите сообщение, которое будет показано всем пользователям..."
                    rows={3}
                    data-testid="textarea-system-message"
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <Label htmlFor="maxDocuments">Максимум документов на пользователя</Label>
                    <Input
                      id="maxDocuments"
                      type="number"
                      value={maxDocumentsPerUser}
                      onChange={(e) => setMaxDocumentsPerUser(e.target.value)}
                      data-testid="input-max-documents"
                    />
                  </div>
                  <div>
                    <Label htmlFor="sessionTimeout">Время ожидания сессии (минуты)</Label>
                    <Input
                      id="sessionTimeout"
                      type="number"
                      value={sessionTimeout}
                      onChange={(e) => setSessionTimeout(e.target.value)}
                      data-testid="input-session-timeout"
                    />
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label>Уведомления</Label>
                      <p className="text-sm text-muted-foreground">
                        Отправлять уведомления администраторам
                      </p>
                    </div>
                    <Switch
                      checked={enableNotifications}
                      onCheckedChange={setEnableNotifications}
                      data-testid="switch-notifications"
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <Label>Логирование</Label>
                      <p className="text-sm text-muted-foreground">
                        Записывать логи действий пользователей
                      </p>
                    </div>
                    <Switch
                      checked={enableLogging}
                      onCheckedChange={setEnableLogging}
                      data-testid="switch-logging"
                    />
                  </div>
                </div>

                <div className="flex justify-end">
                  <Button 
                    onClick={handleSaveSystemSettings}
                    disabled={updateSettingMutation.isPending}
                    data-testid="button-save-system-settings"
                  >
                    {updateSettingMutation.isPending ? "Сохранение..." : "Сохранить настройки"}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="backup">
            <Card>
              <CardHeader>
                <CardTitle>Резервные копии и обслуживание</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <h4 className="font-medium">Экспорт данных</h4>
                    <div className="space-y-3">
                      <Button 
                        variant="outline" 
                        className="w-full justify-start"
                        onClick={handleExportSettings}
                        data-testid="button-export-settings"
                      >
                        <i className="fas fa-download mr-2"></i>
                        Экспорт настроек
                      </Button>
                      <Button 
                        variant="outline" 
                        className="w-full justify-start"
                        data-testid="button-export-users"
                      >
                        <i className="fas fa-users mr-2"></i>
                        Экспорт пользователей
                      </Button>
                      <Button 
                        variant="outline" 
                        className="w-full justify-start"
                        data-testid="button-export-templates"
                      >
                        <i className="fas fa-file-contract mr-2"></i>
                        Экспорт шаблонов
                      </Button>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h4 className="font-medium">Обслуживание</h4>
                    <div className="space-y-3">
                      <Button 
                        variant="outline" 
                        className="w-full justify-start"
                        onClick={handleClearCache}
                        data-testid="button-clear-cache"
                      >
                        <i className="fas fa-broom mr-2"></i>
                        Очистить кэш
                      </Button>
                      <Button 
                        variant="outline" 
                        className="w-full justify-start"
                        data-testid="button-restart-bot"
                      >
                        <i className="fas fa-redo mr-2"></i>
                        Перезапустить бота
                      </Button>
                      <Button 
                        variant="outline" 
                        className="w-full justify-start"
                        data-testid="button-check-health"
                      >
                        <i className="fas fa-heartbeat mr-2"></i>
                        Проверить здоровье системы
                      </Button>
                    </div>
                  </div>
                </div>

                <div className="bg-muted p-4 rounded-lg">
                  <h4 className="font-medium mb-2">Последние резервные копии</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>Автоматическая копия</span>
                      <span className="text-muted-foreground">2 дня назад</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Ручная копия настроек</span>
                      <span className="text-muted-foreground">1 неделю назад</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Экспорт пользователей</span>
                      <span className="text-muted-foreground">2 недели назад</span>
                    </div>
                  </div>
                </div>

                <div className="bg-destructive/10 border border-destructive/20 p-4 rounded-lg">
                  <h4 className="font-medium text-destructive mb-2">Опасная зона</h4>
                  <p className="text-sm text-muted-foreground mb-4">
                    Эти действия необратимы. Будьте осторожны!
                  </p>
                  <div className="space-y-2">
                    <Button 
                      variant="destructive" 
                      size="sm"
                      data-testid="button-reset-settings"
                    >
                      Сбросить все настройки
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
