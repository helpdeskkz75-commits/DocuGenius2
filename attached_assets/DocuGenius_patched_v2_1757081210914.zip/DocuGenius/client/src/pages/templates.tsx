import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Header } from "@/components/layout/header";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import type { Template } from "@shared/schema";

export default function Templates() {
  const [searchTerm, setSearchTerm] = useState("");
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: templates = [], isLoading } = useQuery<Template[]>({
    queryKey: ["/api/templates"],
  });

  const { data: businessSectors = [] } = useQuery({
    queryKey: ["/api/business-sectors"],
  });

  const createTemplateMutation = useMutation({
    mutationFn: async (templateData: any) => {
      const response = await apiRequest("POST", "/api/templates", templateData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/templates"] });
      setIsCreateModalOpen(false);
      toast({
        title: "Успех",
        description: "Шаблон успешно создан",
      });
    },
    onError: () => {
      toast({
        title: "Ошибка",
        description: "Не удалось создать шаблон",
        variant: "destructive",
      });
    },
  });

  const toggleTemplateMutation = useMutation({
    mutationFn: async ({ id, isActive }: { id: string; isActive: boolean }) => {
      const response = await apiRequest("PATCH", `/api/templates/${id}`, { isActive });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/templates"] });
      toast({
        title: "Успех",
        description: "Статус шаблона обновлен",
      });
    },
  });

  const handleCreateTemplate = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    createTemplateMutation.mutate({
      name: formData.get('name'),
      type: formData.get('type'),
      sector: formData.get('sector'),
      googleDocsId: formData.get('googleDocsId'),
      placeholders: (formData.get('placeholders') as string)?.split(',').map(p => p.trim()).filter(Boolean) || [],
    });
  };

  const filteredTemplates = templates.filter(template =>
    template.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    template.type.toLowerCase().includes(searchTerm.toLowerCase()) ||
    template.sector.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'договор': return 'fas fa-file-contract';
      case 'счет': return 'fas fa-receipt';
      case 'акт': return 'fas fa-tasks';
      case 'счет-фактура': return 'fas fa-file-invoice';
      default: return 'fas fa-file-alt';
    }
  };

  return (
    <div className="flex flex-col h-screen overflow-hidden">
      <Header 
        title="Управление шаблонами" 
        description="Шаблоны документов для различных отраслей"
      />

      <main className="flex-1 overflow-y-auto p-6">
        {/* Controls */}
        <div className="mb-6 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Input
              placeholder="Поиск шаблонов..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-64"
              data-testid="input-search-templates"
            />
          </div>
          <Dialog open={isCreateModalOpen} onOpenChange={setIsCreateModalOpen}>
            <DialogTrigger asChild>
              <Button data-testid="button-create-template">
                <i className="fas fa-plus mr-2"></i>
                Создать шаблон
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Создать новый шаблон</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleCreateTemplate} className="space-y-4">
                <div>
                  <Label htmlFor="templateName">Название шаблона</Label>
                  <Input 
                    id="templateName"
                    name="name"
                    placeholder="Например: Договор оказания услуг"
                    required
                    data-testid="input-new-template-name"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="templateType">Тип документа</Label>
                    <Select name="type" required>
                      <SelectTrigger data-testid="select-new-template-type">
                        <SelectValue placeholder="Выберите тип" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="договор">Договор</SelectItem>
                        <SelectItem value="акт">Акт выполненных работ</SelectItem>
                        <SelectItem value="счет">Счет</SelectItem>
                        <SelectItem value="счет-фактура">Счет-фактура</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="templateSector">Отрасль</Label>
                    <Select name="sector" required>
                      <SelectTrigger data-testid="select-new-template-sector">
                        <SelectValue placeholder="Выберите отрасль" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Общая">Общая</SelectItem>
                        {businessSectors.map((sector: any) => (
                          <SelectItem key={sector.id} value={sector.name}>
                            {sector.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div>
                  <Label htmlFor="googleDocsId">Google Docs ID</Label>
                  <Input 
                    id="googleDocsId"
                    name="googleDocsId"
                    placeholder="ID документа Google Docs"
                    required
                    data-testid="input-new-google-docs-id"
                  />
                </div>
                <div>
                  <Label htmlFor="placeholders">Плейсхолдеры (через запятую)</Label>
                  <Input 
                    id="placeholders"
                    name="placeholders"
                    placeholder="CLIENT_NAME, SERVICE_TYPE, COST, DATE"
                    data-testid="input-new-template-placeholders"
                  />
                </div>
                <div className="flex justify-end space-x-3 pt-4">
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => setIsCreateModalOpen(false)}
                    data-testid="button-cancel-template-creation"
                  >
                    Отмена
                  </Button>
                  <Button 
                    type="submit" 
                    disabled={createTemplateMutation.isPending}
                    data-testid="button-submit-new-template"
                  >
                    {createTemplateMutation.isPending ? "Создание..." : "Создать"}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {/* Templates Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredTemplates.map((template) => (
            <Card key={template.id} className="hover:shadow-md transition-shadow" data-testid={`template-card-${template.id}`}>
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                      <i className={`${getTypeIcon(template.type)} text-primary text-sm`}></i>
                    </div>
                    <div className="flex-1 min-w-0">
                      <CardTitle className="text-base truncate" data-testid={`template-name-${template.id}`}>
                        {template.name}
                      </CardTitle>
                      <div className="flex items-center space-x-2 mt-1">
                        <Badge variant="outline" data-testid={`template-type-${template.id}`}>
                          {template.type}
                        </Badge>
                        <Badge variant="secondary" data-testid={`template-sector-${template.id}`}>
                          {template.sector}
                        </Badge>
                      </div>
                    </div>
                  </div>
                  <Switch
                    checked={template.isActive}
                    onCheckedChange={(checked) => 
                      toggleTemplateMutation.mutate({ id: template.id, isActive: checked })
                    }
                    disabled={toggleTemplateMutation.isPending}
                    data-testid={`switch-template-active-${template.id}`}
                  />
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div>
                    <p className="text-xs text-muted-foreground mb-1">Google Docs ID:</p>
                    <p className="text-sm font-mono bg-muted p-2 rounded text-xs" data-testid={`template-docs-id-${template.id}`}>
                      {template.googleDocsId}
                    </p>
                  </div>
                  {template.placeholders && template.placeholders.length > 0 && (
                    <div>
                      <p className="text-xs text-muted-foreground mb-2">Плейсхолдеры:</p>
                      <div className="flex flex-wrap gap-1">
                        {template.placeholders.map((placeholder, index) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            {placeholder}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}
                  <div className="text-xs text-muted-foreground">
                    Создан: {new Date(template.createdAt).toLocaleDateString('ru-RU')}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredTemplates.length === 0 && !isLoading && (
          <div className="text-center py-12">
            <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
              <i className="fas fa-file-contract text-muted-foreground text-xl"></i>
            </div>
            <h3 className="text-lg font-medium mb-2">Шаблоны не найдены</h3>
            <p className="text-muted-foreground mb-4">
              {searchTerm ? "По вашему запросу ничего не найдено" : "Создайте первый шаблон документа"}
            </p>
            <Button onClick={() => setIsCreateModalOpen(true)} data-testid="button-create-first-template">
              <i className="fas fa-plus mr-2"></i>
              Создать первый шаблон
            </Button>
          </div>
        )}
      </main>
    </div>
  );
}
