import { useQuery } from "@tanstack/react-query";
import { Header } from "@/components/layout/header";
import { StatsCard } from "@/components/stats-card";
import { QuickActions } from "@/components/quick-actions";
import { RecentDocuments } from "@/components/recent-documents";
import { BusinessSectors } from "@/components/business-sectors";
import { SystemStatus } from "@/components/system-status";

interface DashboardStats {
  activeUsers: number;
  documentsCreated: number;
  templates: number;
  aiSuccessRate: number;
  botActive: boolean;
}

export default function Dashboard() {
  const { data: stats, isLoading } = useQuery<DashboardStats>({
    queryKey: ["/api/dashboard/stats"],
  });

  return (
    <div className="flex flex-col h-screen overflow-hidden">
      <Header 
        title="Дашборд" 
        description="Управление Telegram-ботом для документооборота"
      >
        {/* Bot Status */}
        <div className="flex items-center space-x-2">
          <span className={`w-2 h-2 rounded-full ${stats?.botActive ? 'bg-accent' : 'bg-destructive'}`}></span>
          <span className="text-sm text-muted-foreground" data-testid="bot-status">
            {stats?.botActive ? 'Бот активен' : 'Бот неактивен'}
          </span>
        </div>
        {/* Notifications */}
        <button className="relative p-2 text-muted-foreground hover:text-foreground" data-testid="button-notifications">
          <i className="fas fa-bell"></i>
          <span className="absolute -top-1 -right-1 w-4 h-4 bg-destructive text-destructive-foreground text-xs rounded-full flex items-center justify-center">
            3
          </span>
        </button>
      </Header>

      {/* Dashboard Content */}
      <main className="flex-1 overflow-y-auto p-6">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <StatsCard
            title="Активные пользователи"
            value={isLoading ? "..." : stats?.activeUsers || 0}
            icon="fas fa-users"
            iconBgColor="bg-primary/10"
            iconTextColor="text-primary"
            trend={{ value: "+12%", label: "за месяц", positive: true }}
            testId="stats-active-users"
          />
          
          <StatsCard
            title="Документов создано"
            value={isLoading ? "..." : stats?.documentsCreated || 0}
            icon="fas fa-file-alt"
            iconBgColor="bg-accent/10"
            iconTextColor="text-accent"
            trend={{ value: "+8%", label: "за неделю", positive: true }}
            testId="stats-documents-created"
          />
          
          <StatsCard
            title="Шаблонов"
            value={isLoading ? "..." : stats?.templates || 0}
            icon="fas fa-file-contract"
            iconBgColor="bg-chart-3/10"
            iconTextColor="text-chart-3"
            trend={{ value: "Активных шаблонов", label: "", positive: true }}
            testId="stats-templates"
          />
          
          <StatsCard
            title="Успешность ИИ"
            value={isLoading ? "..." : `${stats?.aiSuccessRate || 0}%`}
            icon="fas fa-robot"
            iconBgColor="bg-chart-4/10"
            iconTextColor="text-chart-4"
            trend={{ value: "+2.3%", label: "улучшение", positive: true }}
            testId="stats-ai-success-rate"
          />
        </div>
        
        {/* Quick Actions */}
        <QuickActions className="mb-8" />
        
        {/* Recent Activity */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          <RecentDocuments />
          <BusinessSectors />
        </div>
        
        {/* System Status */}
        <SystemStatus />
      </main>
    </div>
  );
}
