import { Header } from "@/components/layout/header";
import { Card, CardContent } from "@/components/ui/card";

export default function Counterparties() {
  return (
    <div className="flex flex-col h-screen overflow-hidden">
      <Header 
        title="Управление контрагентами" 
        description="Просмотр и управление контрагентами пользователей"
      />

      <main className="flex-1 overflow-y-auto p-6">
        <Card>
          <CardContent className="p-6">
            <div className="text-center py-12">
              <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="fas fa-building text-muted-foreground text-xl"></i>
              </div>
              <h3 className="text-lg font-medium mb-2">Управление контрагентами</h3>
              <p className="text-muted-foreground mb-4">
                Функционал в разработке. Здесь будет отображаться список всех контрагентов пользователей.
              </p>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
