import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Header } from "@/components/layout/header";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import type { User } from "@shared/schema";

export default function Users() {
  const [searchTerm, setSearchTerm] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: users = [], isLoading } = useQuery<User[]>({
    queryKey: ["/api/users"],
  });

  const toggleUserMutation = useMutation({
    mutationFn: async ({ id, isActive }: { id: string; isActive: boolean }) => {
      const response = await apiRequest("PATCH", `/api/users/${id}`, { isActive });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      toast({
        title: "Успех",
        description: "Статус пользователя обновлен",
      });
    },
    onError: () => {
      toast({
        title: "Ошибка",
        description: "Не удалось обновить статус пользователя",
        variant: "destructive",
      });
    },
  });

  const filteredUsers = users.filter(user =>
    user.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.firstName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.lastName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.businessName?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="flex flex-col h-screen overflow-hidden">
      <Header 
        title="Управление пользователями" 
        description="Просмотр и управление пользователями Telegram-бота"
      />

      <main className="flex-1 overflow-y-auto p-6">
        {/* Search and Filters */}
        <div className="mb-6">
          <div className="flex items-center space-x-4">
            <div className="flex-1 max-w-sm">
              <Input
                placeholder="Поиск пользователей..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                data-testid="input-search-users"
              />
            </div>
            <Button data-testid="button-refresh-users">
              <i className="fas fa-refresh mr-2"></i>
              Обновить
            </Button>
          </div>
        </div>

        {/* Users List */}
        <Card>
          <CardContent className="p-0">
            {isLoading ? (
              <div className="p-6">
                <div className="space-y-4">
                  {[...Array(5)].map((_, i) => (
                    <div key={i} className="animate-pulse">
                      <div className="flex items-center space-x-4 p-4">
                        <div className="w-10 h-10 bg-muted rounded-full"></div>
                        <div className="flex-1">
                          <div className="h-4 bg-muted rounded w-1/3 mb-2"></div>
                          <div className="h-3 bg-muted rounded w-1/2"></div>
                        </div>
                        <div className="w-20 h-6 bg-muted rounded"></div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ) : filteredUsers.length === 0 ? (
              <div className="text-center py-12">
                <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
                  <i className="fas fa-users text-muted-foreground text-xl"></i>
                </div>
                <h3 className="text-lg font-medium mb-2">Пользователи не найдены</h3>
                <p className="text-muted-foreground">
                  {searchTerm ? "По вашему запросу ничего не найдено" : "Пользователи еще не зарегистрированы"}
                </p>
              </div>
            ) : (
              <div className="divide-y divide-border">
                {filteredUsers.map((user) => (
                  <div 
                    key={user.id} 
                    className="p-4 hover:bg-muted/50 transition-colors"
                    data-testid={`user-row-${user.id}`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4">
                        <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                          <span className="text-sm font-medium text-primary">
                            {user.firstName?.charAt(0) || user.username.charAt(0)}
                          </span>
                        </div>
                        <div>
                          <div className="flex items-center space-x-2">
                            <h3 className="font-medium" data-testid={`user-name-${user.id}`}>
                              {user.firstName && user.lastName 
                                ? `${user.firstName} ${user.lastName}`
                                : user.username
                              }
                            </h3>
                            <Badge variant="outline" data-testid={`user-business-type-${user.id}`}>
                              {user.businessType || "Не указан"}
                            </Badge>
                          </div>
                          <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                            <span data-testid={`user-business-name-${user.id}`}>
                              {user.businessName || "Не указано"}
                            </span>
                            {user.sector && (
                              <Badge variant="secondary" data-testid={`user-sector-${user.id}`}>
                                {user.sector}
                              </Badge>
                            )}
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex items-center space-x-4">
                        <div className="flex items-center space-x-2">
                          <span className="text-sm">
                            {user.isActive ? 'Активен' : 'Неактивен'}
                          </span>
                          <Switch
                            checked={user.isActive}
                            onCheckedChange={(checked) => 
                              toggleUserMutation.mutate({ id: user.id, isActive: checked })
                            }
                            disabled={toggleUserMutation.isPending}
                            data-testid={`switch-user-active-${user.id}`}
                          />
                        </div>
                        
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button variant="outline" size="sm" data-testid={`button-view-user-${user.id}`}>
                              <i className="fas fa-eye mr-2"></i>
                              Просмотр
                            </Button>
                          </DialogTrigger>
                          <DialogContent>
                            <DialogHeader>
                              <DialogTitle>Информация о пользователе</DialogTitle>
                            </DialogHeader>
                            <div className="space-y-4">
                              <div className="grid grid-cols-2 gap-4">
                                <div>
                                  <label className="text-sm font-medium">Имя</label>
                                  <p className="text-sm text-muted-foreground">
                                    {user.firstName || "Не указано"}
                                  </p>
                                </div>
                                <div>
                                  <label className="text-sm font-medium">Фамилия</label>
                                  <p className="text-sm text-muted-foreground">
                                    {user.lastName || "Не указано"}
                                  </p>
                                </div>
                              </div>
                              <div>
                                <label className="text-sm font-medium">Telegram ID</label>
                                <p className="text-sm text-muted-foreground">{user.telegramId}</p>
                              </div>
                              <div>
                                <label className="text-sm font-medium">Название бизнеса</label>
                                <p className="text-sm text-muted-foreground">
                                  {user.businessName || "Не указано"}
                                </p>
                              </div>
                              <div>
                                <label className="text-sm font-medium">Отрасль</label>
                                <p className="text-sm text-muted-foreground">
                                  {user.sector || "Не указана"}
                                </p>
                              </div>
                              <div>
                                <label className="text-sm font-medium">Дата регистрации</label>
                                <p className="text-sm text-muted-foreground">
                                  {user.createdAt ? new Date(user.createdAt).toLocaleDateString('ru-RU') : "Не указана"}
                                </p>
                              </div>
                            </div>
                          </DialogContent>
                        </Dialog>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
