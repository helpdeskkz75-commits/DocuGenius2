import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Header } from "@/components/layout/header";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import type { BusinessSector } from "@shared/schema";

export default function AIConfig() {
  const [isConfigModalOpen, setIsConfigModalOpen] = useState(false);
  const [selectedSector, setSelectedSector] = useState<BusinessSector | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: sectors = [], isLoading } = useQuery<BusinessSector[]>({
    queryKey: ["/api/business-sectors"],
  });

  const updateSectorMutation = useMutation({
    mutationFn: async ({ id, aiPrompt }: { id: string; aiPrompt: string }) => {
      const response = await apiRequest("PATCH", `/api/business-sectors/${id}`, { aiPrompt });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/business-sectors"] });
      setIsConfigModalOpen(false);
      setSelectedSector(null);
      toast({
        title: "Успех",
        description: "ИИ конфигурация обновлена",
      });
    },
    onError: () => {
      toast({
        title: "Ошибка",
        description: "Не удалось обновить конфигурацию ИИ",
        variant: "destructive",
      });
    },
  });

  const toggleSectorMutation = useMutation({
    mutationFn: async ({ id, isActive }: { id: string; isActive: boolean }) => {
      const response = await apiRequest("PATCH", `/api/business-sectors/${id}`, { isActive });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/business-sectors"] });
      toast({
        title: "Успех",
        description: "Статус отрасли обновлен",
      });
    },
  });

  const handleConfigSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!selectedSector) return;

    const formData = new FormData(e.currentTarget);
    const aiPrompt = formData.get('aiPrompt') as string;

    updateSectorMutation.mutate({ id: selectedSector.id, aiPrompt });
  };

  const openConfigModal = (sector: BusinessSector) => {
    setSelectedSector(sector);
    setIsConfigModalOpen(true);
  };

  const getSectorIcon = (icon: string) => {
    return icon || 'fas fa-industry';
  };

  return (
    <div className="flex flex-col h-screen overflow-hidden">
      <Header 
        title="ИИ Конфигурация" 
        description="Настройка ИИ-помощника для различных отраслей бизнеса"
      />

      <main className="flex-1 overflow-y-auto p-6">
        {/* Overview Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Настроенные отрасли
              </CardTitle>
              <div className="text-2xl font-bold" data-testid="configured-sectors-count">
                {sectors.filter(s => s.aiPrompt).length}
              </div>
            </CardHeader>
          </Card>
          
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Активные отрасли
              </CardTitle>
              <div className="text-2xl font-bold" data-testid="active-sectors-count">
                {sectors.filter(s => s.isActive).length}
              </div>
            </CardHeader>
          </Card>
          
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Общее количество пользователей
              </CardTitle>
              <div className="text-2xl font-bold" data-testid="total-users-count">
                {sectors.reduce((total, sector) => total + (sector.userCount || 0), 0)}
              </div>
            </CardHeader>
          </Card>
        </div>

        {/* Sectors Configuration */}
        <Card>
          <CardHeader>
            <CardTitle>Конфигурация по отраслям</CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="space-y-4">
                {[...Array(4)].map((_, i) => (
                  <div key={i} className="animate-pulse">
                    <div className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex items-center space-x-4">
                        <div className="w-12 h-12 bg-muted rounded-lg"></div>
                        <div>
                          <div className="h-4 bg-muted rounded w-32 mb-2"></div>
                          <div className="h-3 bg-muted rounded w-20"></div>
                        </div>
                      </div>
                      <div className="w-24 h-8 bg-muted rounded"></div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="space-y-4">
                {sectors.map((sector) => (
                  <div 
                    key={sector.id} 
                    className="flex items-center justify-between p-4 border border-border rounded-lg hover:bg-muted/50 transition-colors"
                    data-testid={`sector-config-${sector.id}`}
                  >
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                        <i className={`${getSectorIcon(sector.icon)} text-primary`}></i>
                      </div>
                      <div>
                        <h3 className="font-medium" data-testid={`sector-name-${sector.id}`}>
                          {sector.name}
                        </h3>
                        <div className="flex items-center space-x-2 mt-1">
                          <span className="text-sm text-muted-foreground">
                            {sector.userCount || 0} пользователей
                          </span>
                          {sector.aiPrompt ? (
                            <Badge variant="default" className="bg-accent text-accent-foreground">
                              Настроено
                            </Badge>
                          ) : (
                            <Badge variant="secondary">
                              Требует настройки
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-4">
                      <div className="flex items-center space-x-2">
                        <span className="text-sm">
                          {sector.isActive ? 'Активна' : 'Неактивна'}
                        </span>
                        <Switch
                          checked={sector.isActive}
                          onCheckedChange={(checked) => 
                            toggleSectorMutation.mutate({ id: sector.id, isActive: checked })
                          }
                          disabled={toggleSectorMutation.isPending}
                          data-testid={`switch-sector-active-${sector.id}`}
                        />
                      </div>
                      
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => openConfigModal(sector)}
                        data-testid={`button-config-sector-${sector.id}`}
                      >
                        <i className="fas fa-cogs mr-2"></i>
                        Настроить ИИ
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Configuration Modal */}
        <Dialog open={isConfigModalOpen} onOpenChange={setIsConfigModalOpen}>
          <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>
                Настройка ИИ для отрасли: {selectedSector?.name}
              </DialogTitle>
            </DialogHeader>
            
            {selectedSector && (
              <form onSubmit={handleConfigSubmit} className="space-y-6">
                <div>
                  <Label htmlFor="aiPrompt">Системный промпт для ИИ</Label>
                  <Textarea
                    id="aiPrompt"
                    name="aiPrompt"
                    rows={12}
                    defaultValue={selectedSector.aiPrompt || ''}
                    placeholder={`Введите системный промпт для ИИ в отрасли "${selectedSector.name}". Например:

Ты помощник для создания документов в сфере стоматологии. 
При создании договоров учитывай специфику медицинских услуг:
- Указывай необходимые лицензии и сертификаты
- Включай информацию о гарантийных обязательствах
- Учитывай особенности медицинского права
- Используй профессиональную терминологию

Всегда запрашивай у пользователя:
- Тип стоматологической услуги
- Стоимость лечения
- Сроки оказания услуг
- Гарантийные обязательства`}
                    className="min-h-[300px]"
                    data-testid="textarea-ai-prompt"
                  />
                  <p className="text-sm text-muted-foreground mt-2">
                    Этот промпт будет использоваться ИИ при создании документов для отрасли "{selectedSector.name}".
                    Опишите специфику отрасли, требования к документам и особенности терминологии.
                  </p>
                </div>
                
                <div className="bg-muted p-4 rounded-lg">
                  <h4 className="font-medium mb-2">Рекомендации по созданию промптов:</h4>
                  <ul className="text-sm text-muted-foreground space-y-1">
                    <li>• Укажите специфику отрасли и особенности документооборота</li>
                    <li>• Опишите обязательные элементы, которые должны присутствовать в документах</li>
                    <li>• Укажите профессиональную терминологию, которую следует использовать</li>
                    <li>• Определите, какую дополнительную информацию нужно запрашивать у пользователей</li>
                    <li>• Добавьте требования к форматированию и структуре документов</li>
                  </ul>
                </div>
                
                <div className="flex justify-end space-x-3 pt-4">
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => setIsConfigModalOpen(false)}
                    data-testid="button-cancel-ai-config"
                  >
                    Отмена
                  </Button>
                  <Button 
                    type="submit" 
                    disabled={updateSectorMutation.isPending}
                    data-testid="button-save-ai-config"
                  >
                    {updateSectorMutation.isPending ? "Сохранение..." : "Сохранить конфигурацию"}
                  </Button>
                </div>
              </form>
            )}
          </DialogContent>
        </Dialog>
      </main>
    </div>
  );
}
