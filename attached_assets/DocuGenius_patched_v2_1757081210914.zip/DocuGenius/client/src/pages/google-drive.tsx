import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Header } from "@/components/layout/header";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";

interface FolderStructure {
  root: string;
  folders: FolderNode[];
}

interface FolderNode {
  name: string;
  path: string;
  children?: FolderNode[];
  documentsCount?: number;
  size?: string;
}

export default function GoogleDrive() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedUserId, setSelectedUserId] = useState<string | null>(null);
  const [isCreateFolderModalOpen, setIsCreateFolderModalOpen] = useState(false);
  const { toast } = useToast();

  const { data: driveStatus } = useQuery({
    queryKey: ["/api/google-drive/status"],
  });

  const { data: users = [] } = useQuery({
    queryKey: ["/api/users"],
  });

  const { data: folderStructure, isLoading: isLoadingFolders } = useQuery<FolderStructure>({
    queryKey: ["/api/google-drive/folders", selectedUserId],
    enabled: !!selectedUserId,
  });

  const handleCreateFolder = () => {
    toast({
      title: "Папка создана",
      description: "Новая папка успешно создана в Google Drive",
    });
    setIsCreateFolderModalOpen(false);
  };

  const handleSyncFolder = (folderPath: string) => {
    toast({
      title: "Синхронизация запущена",
      description: `Синхронизация папки "${folderPath}" начата`,
    });
  };

  const renderFolderTree = (folders: FolderNode[], level = 0) => {
    return folders.map((folder, index) => (
      <div key={index} className="space-y-2">
        <div 
          className="flex items-center justify-between p-3 bg-card border border-border rounded-lg hover:bg-muted/50 transition-colors"
          style={{ marginLeft: `${level * 20}px` }}
          data-testid={`folder-item-${folder.name.replace(/\s+/g, '-').toLowerCase()}`}
        >
          <div className="flex items-center space-x-3">
            <i className="fas fa-folder text-chart-3"></i>
            <div>
              <h4 className="font-medium" data-testid={`folder-name-${folder.name.replace(/\s+/g, '-').toLowerCase()}`}>
                {folder.name}
              </h4>
              <p className="text-xs text-muted-foreground" data-testid={`folder-path-${folder.name.replace(/\s+/g, '-').toLowerCase()}`}>
                {folder.path}
              </p>
            </div>
          </div>
          
          <div className="flex items-center space-x-3">
            {folder.documentsCount !== undefined && (
              <Badge variant="outline" data-testid={`folder-docs-count-${folder.name.replace(/\s+/g, '-').toLowerCase()}`}>
                {folder.documentsCount} док.
              </Badge>
            )}
            {folder.size && (
              <Badge variant="secondary" data-testid={`folder-size-${folder.name.replace(/\s+/g, '-').toLowerCase()}`}>
                {folder.size}
              </Badge>
            )}
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => handleSyncFolder(folder.path)}
              data-testid={`button-sync-folder-${folder.name.replace(/\s+/g, '-').toLowerCase()}`}
            >
              <i className="fas fa-sync mr-2"></i>
              Синхронизировать
            </Button>
          </div>
        </div>
        
        {folder.children && folder.children.length > 0 && (
          <div className="ml-4">
            {renderFolderTree(folder.children, level + 1)}
          </div>
        )}
      </div>
    ));
  };

  const filteredUsers = users.filter((user: any) =>
    user.businessName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.firstName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.lastName?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="flex flex-col h-screen overflow-hidden">
      <Header 
        title="Google Drive" 
        description="Управление структурой папок и файлов в Google Drive"
      >
        <div className="flex items-center space-x-2">
          <span className={`w-2 h-2 rounded-full ${driveStatus?.status === 'operational' ? 'bg-accent' : 'bg-destructive'}`}></span>
          <span className="text-sm text-muted-foreground" data-testid="drive-status">
            {driveStatus?.message || 'Проверка статуса...'}
          </span>
        </div>
      </Header>

      <main className="flex-1 overflow-hidden">
        <div className="flex h-full">
          {/* Users Sidebar */}
          <div className="w-80 border-r border-border bg-card p-4 overflow-y-auto">
            <div className="space-y-4">
              <div>
                <h3 className="font-medium mb-3">Пользователи</h3>
                <Input
                  placeholder="Поиск пользователей..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  data-testid="input-search-users-drive"
                />
              </div>
              
              <div className="space-y-2">
                {filteredUsers.map((user: any) => (
                  <button
                    key={user.id}
                    onClick={() => setSelectedUserId(user.id)}
                    className={`w-full text-left p-3 rounded-lg border transition-colors ${
                      selectedUserId === user.id 
                        ? 'bg-primary text-primary-foreground border-primary' 
                        : 'bg-background border-border hover:bg-muted'
                    }`}
                    data-testid={`button-select-user-${user.id}`}
                  >
                    <div>
                      <p className="font-medium" data-testid={`user-business-name-${user.id}`}>
                        {user.businessName || `${user.firstName} ${user.lastName}`.trim()}
                      </p>
                      <p className="text-xs opacity-70" data-testid={`user-type-${user.id}`}>
                        {user.businessType || 'Тип не указан'}
                      </p>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Main Content */}
          <div className="flex-1 p-6 overflow-y-auto">
            {!selectedUserId ? (
              <div className="text-center py-12">
                <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
                  <i className="fas fa-folder text-muted-foreground text-xl"></i>
                </div>
                <h3 className="text-lg font-medium mb-2">Выберите пользователя</h3>
                <p className="text-muted-foreground">
                  Выберите пользователя из списка слева, чтобы просмотреть структуру его папок в Google Drive
                </p>
              </div>
            ) : (
              <div className="space-y-6">
                {/* Actions */}
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-semibold">Структура папок</h3>
                  <div className="flex items-center space-x-3">
                    <Dialog open={isCreateFolderModalOpen} onOpenChange={setIsCreateFolderModalOpen}>
                      <DialogTrigger asChild>
                        <Button data-testid="button-create-folder">
                          <i className="fas fa-folder-plus mr-2"></i>
                          Создать папку
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Создать новую папку</DialogTitle>
                        </DialogHeader>
                        <div className="space-y-4">
                          <div>
                            <Label htmlFor="folderName">Название папки</Label>
                            <Input 
                              id="folderName" 
                              placeholder="Введите название папки"
                              data-testid="input-folder-name"
                            />
                          </div>
                          <div>
                            <Label htmlFor="parentFolder">Родительская папка</Label>
                            <Input 
                              id="parentFolder" 
                              placeholder="Путь к родительской папке"
                              data-testid="input-parent-folder"
                            />
                          </div>
                          <div className="flex justify-end space-x-3">
                            <Button 
                              variant="outline" 
                              onClick={() => setIsCreateFolderModalOpen(false)}
                              data-testid="button-cancel-folder-creation"
                            >
                              Отмена
                            </Button>
                            <Button 
                              onClick={handleCreateFolder}
                              data-testid="button-submit-folder-creation"
                            >
                              Создать
                            </Button>
                          </div>
                        </div>
                      </DialogContent>
                    </Dialog>
                    
                    <Button variant="outline" data-testid="button-refresh-folders">
                      <i className="fas fa-refresh mr-2"></i>
                      Обновить
                    </Button>
                  </div>
                </div>

                {/* Folder Structure */}
                {isLoadingFolders ? (
                  <div className="space-y-4">
                    {[...Array(3)].map((_, i) => (
                      <div key={i} className="animate-pulse">
                        <div className="flex items-center space-x-3 p-3 border rounded-lg">
                          <div className="w-5 h-5 bg-muted rounded"></div>
                          <div className="flex-1">
                            <div className="h-4 bg-muted rounded w-1/3 mb-2"></div>
                            <div className="h-3 bg-muted rounded w-1/2"></div>
                          </div>
                          <div className="w-20 h-6 bg-muted rounded"></div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : folderStructure?.folders && folderStructure.folders.length > 0 ? (
                  <div className="space-y-4">
                    {renderFolderTree(folderStructure.folders)}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
                      <i className="fas fa-folder-open text-muted-foreground text-xl"></i>
                    </div>
                    <h3 className="text-lg font-medium mb-2">Папки не найдены</h3>
                    <p className="text-muted-foreground mb-4">
                      У данного пользователя пока нет папок в Google Drive
                    </p>
                    <Button onClick={() => setIsCreateFolderModalOpen(true)} data-testid="button-create-first-folder">
                      <i className="fas fa-folder-plus mr-2"></i>
                      Создать первую папку
                    </Button>
                  </div>
                )}

                {/* Storage Statistics */}
                <Card>
                  <CardHeader>
                    <CardTitle>Статистика хранилища</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                      <div className="text-center">
                        <div className="text-2xl font-bold text-primary" data-testid="total-folders-count">
                          {folderStructure?.folders?.length || 0}
                        </div>
                        <p className="text-sm text-muted-foreground">Всего папок</p>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-accent" data-testid="total-documents-count">
                          42
                        </div>
                        <p className="text-sm text-muted-foreground">Документов</p>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-chart-3" data-testid="total-storage-used">
                          2.4 МБ
                        </div>
                        <p className="text-sm text-muted-foreground">Использовано</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}
