import { useState } from "react";
import { Header } from "@/components/layout/header";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";

interface Integration {
  id: string;
  name: string;
  description: string;
  icon: string;
  status: 'connected' | 'disconnected' | 'error';
  category: 'payment' | 'crm' | 'accounting' | 'storage' | 'communication';
  isEnabled: boolean;
  config?: Record<string, any>;
}

const mockIntegrations: Integration[] = [
  {
    id: 'kaspi-pay',
    name: 'Kaspi Pay',
    description: 'Интеграция с платежной системой Kaspi для автоматической обработки платежей',
    icon: 'fas fa-credit-card',
    status: 'disconnected',
    category: 'payment',
    isEnabled: false,
  },
  {
    id: 'halyk-bank',
    name: 'Halyk Bank API',
    description: 'Интеграция с банковским API для выгрузки выписок и автоматической сверки',
    icon: 'fas fa-university',
    status: 'disconnected',
    category: 'payment',
    isEnabled: false,
  },
  {
    id: 'onesec-crm',
    name: '1С:CRM',
    description: 'Синхронизация контрагентов и документов с системой 1С',
    icon: 'fas fa-users-cog',
    status: 'disconnected',
    category: 'crm',
    isEnabled: false,
  },
  {
    id: 'google-calendar',
    name: 'Google Calendar',
    description: 'Автоматическое создание событий при заключении договоров',
    icon: 'fas fa-calendar',
    status: 'connected',
    category: 'communication',
    isEnabled: true,
  },
  {
    id: 'excel-export',
    name: 'Excel Export',
    description: 'Экспорт отчетов и документов в формате Excel',
    icon: 'fas fa-file-excel',
    status: 'connected',
    category: 'storage',
    isEnabled: true,
  },
  {
    id: 'sms-center',
    name: 'SMS Центр',
    description: 'Отправка SMS уведомлений клиентам о готовности документов',
    icon: 'fas fa-sms',
    status: 'error',
    category: 'communication',
    isEnabled: false,
  },
];

export default function Integrations() {
  const [integrations, setIntegrations] = useState<Integration[]>(mockIntegrations);
  const [selectedIntegration, setSelectedIntegration] = useState<Integration | null>(null);
  const [isConfigModalOpen, setIsConfigModalOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('all');
  const { toast } = useToast();

  const handleToggleIntegration = (id: string, enabled: boolean) => {
    setIntegrations(prev => 
      prev.map(integration => 
        integration.id === id 
          ? { ...integration, isEnabled: enabled, status: enabled ? 'connected' : 'disconnected' }
          : integration
      )
    );
    toast({
      title: enabled ? "Интеграция включена" : "Интеграция отключена",
      description: `Статус интеграции успешно изменен`,
    });
  };

  const openConfigModal = (integration: Integration) => {
    setSelectedIntegration(integration);
    setIsConfigModalOpen(true);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'connected': return 'bg-accent text-accent-foreground';
      case 'error': return 'bg-destructive text-destructive-foreground';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'connected': return 'Подключено';
      case 'error': return 'Ошибка';
      default: return 'Не подключено';
    }
  };

  const getCategoryText = (category: string) => {
    switch (category) {
      case 'payment': return 'Платежи';
      case 'crm': return 'CRM';
      case 'accounting': return 'Учет';
      case 'storage': return 'Хранение';
      case 'communication': return 'Коммуникации';
      default: return 'Прочее';
    }
  };

  const filteredIntegrations = activeTab === 'all' 
    ? integrations 
    : integrations.filter(integration => integration.category === activeTab);

  return (
    <div className="flex flex-col h-screen overflow-hidden">
      <Header 
        title="Интеграции и плагины" 
        description="Управление внешними интеграциями и расширениями функциональности"
      />

      <main className="flex-1 overflow-y-auto p-6">
        {/* Overview Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Всего интеграций
              </CardTitle>
              <div className="text-2xl font-bold" data-testid="total-integrations">
                {integrations.length}
              </div>
            </CardHeader>
          </Card>
          
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Активных
              </CardTitle>
              <div className="text-2xl font-bold text-accent" data-testid="active-integrations">
                {integrations.filter(i => i.status === 'connected').length}
              </div>
            </CardHeader>
          </Card>
          
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                С ошибками
              </CardTitle>
              <div className="text-2xl font-bold text-destructive" data-testid="error-integrations">
                {integrations.filter(i => i.status === 'error').length}
              </div>
            </CardHeader>
          </Card>
          
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Готовы к настройке
              </CardTitle>
              <div className="text-2xl font-bold text-muted-foreground" data-testid="pending-integrations">
                {integrations.filter(i => i.status === 'disconnected').length}
              </div>
            </CardHeader>
          </Card>
        </div>

        {/* Integrations Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList>
            <TabsTrigger value="all" data-testid="tab-all-integrations">Все</TabsTrigger>
            <TabsTrigger value="payment" data-testid="tab-payment-integrations">Платежи</TabsTrigger>
            <TabsTrigger value="crm" data-testid="tab-crm-integrations">CRM</TabsTrigger>
            <TabsTrigger value="accounting" data-testid="tab-accounting-integrations">Учет</TabsTrigger>
            <TabsTrigger value="storage" data-testid="tab-storage-integrations">Хранение</TabsTrigger>
            <TabsTrigger value="communication" data-testid="tab-communication-integrations">Коммуникации</TabsTrigger>
          </TabsList>

          <TabsContent value={activeTab} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredIntegrations.map((integration) => (
                <Card key={integration.id} className="hover:shadow-md transition-shadow" data-testid={`integration-card-${integration.id}`}>
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                          <i className={`${integration.icon} text-primary`}></i>
                        </div>
                        <div>
                          <CardTitle className="text-base" data-testid={`integration-name-${integration.id}`}>
                            {integration.name}
                          </CardTitle>
                          <Badge variant="outline" className="mt-1" data-testid={`integration-category-${integration.id}`}>
                            {getCategoryText(integration.category)}
                          </Badge>
                        </div>
                      </div>
                      <Switch
                        checked={integration.isEnabled}
                        onCheckedChange={(checked) => handleToggleIntegration(integration.id, checked)}
                        data-testid={`switch-integration-${integration.id}`}
                      />
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground mb-4" data-testid={`integration-description-${integration.id}`}>
                      {integration.description}
                    </p>
                    
                    <div className="flex items-center justify-between">
                      <Badge className={getStatusColor(integration.status)} data-testid={`integration-status-${integration.id}`}>
                        {getStatusText(integration.status)}
                      </Badge>
                      
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => openConfigModal(integration)}
                        data-testid={`button-configure-${integration.id}`}
                      >
                        <i className="fas fa-cog mr-2"></i>
                        Настроить
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {filteredIntegrations.length === 0 && (
              <div className="text-center py-12">
                <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
                  <i className="fas fa-puzzle-piece text-muted-foreground text-xl"></i>
                </div>
                <h3 className="text-lg font-medium mb-2">Интеграции не найдены</h3>
                <p className="text-muted-foreground">
                  В данной категории пока нет доступных интеграций
                </p>
              </div>
            )}
          </TabsContent>
        </Tabs>

        {/* Configuration Modal */}
        <Dialog open={isConfigModalOpen} onOpenChange={setIsConfigModalOpen}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>
                Настройка интеграции: {selectedIntegration?.name}
              </DialogTitle>
            </DialogHeader>
            
            {selectedIntegration && (
              <div className="space-y-6">
                <div className="flex items-center space-x-4 p-4 bg-muted rounded-lg">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                    <i className={`${selectedIntegration.icon} text-primary text-lg`}></i>
                  </div>
                  <div>
                    <h3 className="font-medium">{selectedIntegration.name}</h3>
                    <p className="text-sm text-muted-foreground">{selectedIntegration.description}</p>
                  </div>
                </div>

                {selectedIntegration.id === 'kaspi-pay' && (
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="kaspi-merchant-id">Merchant ID</Label>
                      <Input id="kaspi-merchant-id" placeholder="Введите Merchant ID" data-testid="input-kaspi-merchant-id" />
                    </div>
                    <div>
                      <Label htmlFor="kaspi-secret-key">Secret Key</Label>
                      <Input id="kaspi-secret-key" type="password" placeholder="Введите Secret Key" data-testid="input-kaspi-secret-key" />
                    </div>
                    <div>
                      <Label htmlFor="kaspi-webhook-url">Webhook URL</Label>
                      <Input id="kaspi-webhook-url" placeholder="https://your-domain.com/webhook/kaspi" data-testid="input-kaspi-webhook-url" />
                    </div>
                  </div>
                )}

                {selectedIntegration.id === 'sms-center' && (
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="sms-login">Логин</Label>
                      <Input id="sms-login" placeholder="Введите логин SMS центра" data-testid="input-sms-login" />
                    </div>
                    <div>
                      <Label htmlFor="sms-password">Пароль</Label>
                      <Input id="sms-password" type="password" placeholder="Введите пароль" data-testid="input-sms-password" />
                    </div>
                    <div>
                      <Label htmlFor="sms-sender">Отправитель</Label>
                      <Input id="sms-sender" placeholder="Название отправителя" data-testid="input-sms-sender" />
                    </div>
                  </div>
                )}

                {selectedIntegration.id === 'onesec-crm' && (
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="onesec-server">Сервер 1С</Label>
                      <Input id="onesec-server" placeholder="http://your-1c-server:port/base" data-testid="input-onesec-server" />
                    </div>
                    <div>
                      <Label htmlFor="onesec-username">Пользователь</Label>
                      <Input id="onesec-username" placeholder="Имя пользователя 1С" data-testid="input-onesec-username" />
                    </div>
                    <div>
                      <Label htmlFor="onesec-password">Пароль</Label>
                      <Input id="onesec-password" type="password" placeholder="Пароль пользователя" data-testid="input-onesec-password" />
                    </div>
                  </div>
                )}

                {!['kaspi-pay', 'sms-center', 'onesec-crm'].includes(selectedIntegration.id) && (
                  <div className="text-center py-8">
                    <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
                      <i className="fas fa-cog text-muted-foreground text-xl"></i>
                    </div>
                    <h3 className="text-lg font-medium mb-2">Настройка в разработке</h3>
                    <p className="text-muted-foreground">
                      Интерфейс настройки для данной интеграции будет доступен в следующих версиях
                    </p>
                  </div>
                )}
                
                <div className="flex justify-end space-x-3 pt-4">
                  <Button 
                    variant="outline" 
                    onClick={() => setIsConfigModalOpen(false)}
                    data-testid="button-cancel-integration-config"
                  >
                    Отмена
                  </Button>
                  <Button data-testid="button-save-integration-config">
                    Сохранить настройки
                  </Button>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </main>
    </div>
  );
}
