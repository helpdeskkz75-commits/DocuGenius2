import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient, useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

interface QuickActionsProps {
  className?: string;
}

export function QuickActions({ className }: QuickActionsProps) {
  const [isTemplateModalOpen, setIsTemplateModalOpen] = useState(false);
  const [isUserModalOpen, setIsUserModalOpen] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: businessSectors = [] } = useQuery({
    queryKey: ["/api/business-sectors"],
  });

  const createTemplateMutation = useMutation({
    mutationFn: async (templateData: any) => {
      const response = await apiRequest("POST", "/api/templates", templateData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/templates"] });
      setIsTemplateModalOpen(false);
      toast({
        title: "Успех",
        description: "Шаблон успешно создан",
      });
    },
    onError: () => {
      toast({
        title: "Ошибка",
        description: "Не удалось создать шаблон",
        variant: "destructive",
      });
    },
  });

  const createUserMutation = useMutation({
    mutationFn: async (userData: any) => {
      const response = await apiRequest("POST", "/api/users", userData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      setIsUserModalOpen(false);
      toast({
        title: "Успех",
        description: "Пользователь успешно добавлен",
      });
    },
    onError: () => {
      toast({
        title: "Ошибка",
        description: "Не удалось добавить пользователя",
        variant: "destructive",
      });
    },
  });

  const handleTemplateSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    createTemplateMutation.mutate({
      name: formData.get('name'),
      type: formData.get('type'),
      sector: formData.get('sector'),
      googleDocsId: formData.get('googleDocsId'),
      placeholders: [],
    });
  };

  const handleUserSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    createUserMutation.mutate({
      telegramId: formData.get('telegramId'),
      username: formData.get('username'),
      firstName: formData.get('firstName'),
      lastName: formData.get('lastName'),
      businessType: formData.get('businessType'),
      businessName: formData.get('businessName'),
      sector: formData.get('sector'),
    });
  };

  return (
    <div className={className}>
      <h2 className="text-lg font-semibold mb-4">Быстрые действия</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        
        <Dialog open={isTemplateModalOpen} onOpenChange={setIsTemplateModalOpen}>
          <DialogTrigger asChild>
            <button className="p-4 bg-card border border-border rounded-lg text-left hover:shadow-md transition-shadow" data-testid="button-add-template">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                  <i className="fas fa-plus text-primary"></i>
                </div>
                <div>
                  <h3 className="font-medium">Добавить шаблон</h3>
                  <p className="text-sm text-muted-foreground">Создать новый шаблон документа</p>
                </div>
              </div>
            </button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Добавить шаблон документа</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleTemplateSubmit} className="space-y-4">
              <div>
                <Label htmlFor="name">Название шаблона</Label>
                <Input 
                  id="name"
                  name="name"
                  placeholder="Например: Договор оказания услуг"
                  required
                  data-testid="input-template-name"
                />
              </div>
              <div>
                <Label htmlFor="type">Тип документа</Label>
                <Select name="type" required>
                  <SelectTrigger data-testid="select-template-type">
                    <SelectValue placeholder="Выберите тип" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="договор">Договор</SelectItem>
                    <SelectItem value="акт">Акт выполненных работ</SelectItem>
                    <SelectItem value="счет">Счет</SelectItem>
                    <SelectItem value="счет-фактура">Счет-фактура</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="sector">Отрасль</Label>
                <Select name="sector" required>
                  <SelectTrigger data-testid="select-template-sector">
                    <SelectValue placeholder="Выберите отрасль" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Общая">Общая</SelectItem>
                    {businessSectors.map((sector: any) => (
                      <SelectItem key={sector.id} value={sector.name}>
                        {sector.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="googleDocsId">Google Docs ID</Label>
                <Input 
                  id="googleDocsId"
                  name="googleDocsId"
                  placeholder="ID документа Google Docs"
                  required
                  data-testid="input-google-docs-id"
                />
              </div>
              <div className="flex justify-end space-x-3 pt-4">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setIsTemplateModalOpen(false)}
                  data-testid="button-cancel-template"
                >
                  Отмена
                </Button>
                <Button 
                  type="submit" 
                  disabled={createTemplateMutation.isPending}
                  data-testid="button-submit-template"
                >
                  {createTemplateMutation.isPending ? "Создание..." : "Создать шаблон"}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>

        <Dialog open={isUserModalOpen} onOpenChange={setIsUserModalOpen}>
          <DialogTrigger asChild>
            <button className="p-4 bg-card border border-border rounded-lg text-left hover:shadow-md transition-shadow" data-testid="button-invite-user">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-accent/10 rounded-lg flex items-center justify-center">
                  <i className="fas fa-user-plus text-accent"></i>
                </div>
                <div>
                  <h3 className="font-medium">Пригласить пользователя</h3>
                  <p className="text-sm text-muted-foreground">Добавить нового предпринимателя</p>
                </div>
              </div>
            </button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Добавить пользователя</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleUserSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="firstName">Имя</Label>
                  <Input id="firstName" name="firstName" required data-testid="input-user-firstname" />
                </div>
                <div>
                  <Label htmlFor="lastName">Фамилия</Label>
                  <Input id="lastName" name="lastName" required data-testid="input-user-lastname" />
                </div>
              </div>
              <div>
                <Label htmlFor="username">Username</Label>
                <Input id="username" name="username" required data-testid="input-user-username" />
              </div>
              <div>
                <Label htmlFor="telegramId">Telegram ID</Label>
                <Input id="telegramId" name="telegramId" required data-testid="input-user-telegram-id" />
              </div>
              <div>
                <Label htmlFor="businessType">Тип бизнеса</Label>
                <Select name="businessType" required>
                  <SelectTrigger data-testid="select-user-business-type">
                    <SelectValue placeholder="Выберите тип" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="ИП">ИП</SelectItem>
                    <SelectItem value="ТОО">ТОО</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="businessName">Название бизнеса</Label>
                <Input id="businessName" name="businessName" required data-testid="input-user-business-name" />
              </div>
              <div>
                <Label htmlFor="userSector">Отрасль</Label>
                <Select name="sector" required>
                  <SelectTrigger data-testid="select-user-sector">
                    <SelectValue placeholder="Выберите отрасль" />
                  </SelectTrigger>
                  <SelectContent>
                    {businessSectors.map((sector: any) => (
                      <SelectItem key={sector.id} value={sector.name}>
                        {sector.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="flex justify-end space-x-3 pt-4">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setIsUserModalOpen(false)}
                  data-testid="button-cancel-user"
                >
                  Отмена
                </Button>
                <Button 
                  type="submit" 
                  disabled={createUserMutation.isPending}
                  data-testid="button-submit-user"
                >
                  {createUserMutation.isPending ? "Добавление..." : "Добавить пользователя"}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>

        <button className="p-4 bg-card border border-border rounded-lg text-left hover:shadow-md transition-shadow" data-testid="button-configure-ai">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-chart-3/10 rounded-lg flex items-center justify-center">
              <i className="fas fa-cogs text-chart-3"></i>
            </div>
            <div>
              <h3 className="font-medium">Настроить ИИ</h3>
              <p className="text-sm text-muted-foreground">Конфигурация по отраслям</p>
            </div>
          </div>
        </button>
      </div>
    </div>
  );
}
