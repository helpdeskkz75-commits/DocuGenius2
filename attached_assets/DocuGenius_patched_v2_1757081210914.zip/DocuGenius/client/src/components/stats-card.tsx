interface StatsCardProps {
  title: string;
  value: string | number;
  icon: string;
  iconBgColor: string;
  iconTextColor: string;
  trend?: {
    value: string;
    label: string;
    positive?: boolean;
  };
  testId?: string;
}

export function StatsCard({ 
  title, 
  value, 
  icon, 
  iconBgColor, 
  iconTextColor, 
  trend,
  testId 
}: StatsCardProps) {
  return (
    <div className="bg-card p-6 rounded-lg border border-border" data-testid={testId}>
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-medium text-muted-foreground" data-testid={`${testId}-title`}>
            {title}
          </p>
          <p className="text-2xl font-bold" data-testid={`${testId}-value`}>
            {value}
          </p>
        </div>
        <div className={`w-12 h-12 ${iconBgColor} rounded-lg flex items-center justify-center`}>
          <i className={`${icon} ${iconTextColor}`}></i>
        </div>
      </div>
      {trend && (
        <div className="mt-4">
          <span className={`text-sm ${trend.positive !== false ? 'text-accent' : 'text-destructive'}`}>
            {trend.value}
          </span>
          <span className="text-sm text-muted-foreground ml-1">{trend.label}</span>
        </div>
      )}
    </div>
  );
}
