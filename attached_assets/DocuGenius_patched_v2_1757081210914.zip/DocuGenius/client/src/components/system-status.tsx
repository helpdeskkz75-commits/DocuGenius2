import { useQuery } from "@tanstack/react-query";

interface SystemStatus {
  telegram: {
    status: string;
    message: string;
  };
  googleDrive: {
    status: string;
    message: string;
  };
  googleDocs: {
    status: string;
    message: string;
  };
}

export function SystemStatus() {
  const { data: systemStatus, isLoading } = useQuery<SystemStatus>({
    queryKey: ["/api/system/status"],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'operational': return 'bg-accent';
      case 'warning': return 'bg-chart-3';
      case 'error': return 'bg-destructive';
      default: return 'bg-muted';
    }
  };

  if (isLoading) {
    return (
      <div className="bg-card p-6 rounded-lg border border-border">
        <h2 className="text-lg font-semibold mb-4">Статус системы</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[...Array(3)].map((_, i) => (
            <div key={i} className="animate-pulse">
              <div className="flex items-center space-x-3">
                <div className="w-3 h-3 bg-muted rounded-full"></div>
                <div>
                  <div className="h-4 bg-muted rounded w-24 mb-2"></div>
                  <div className="h-3 bg-muted rounded w-20"></div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="bg-card p-6 rounded-lg border border-border">
      <h2 className="text-lg font-semibold mb-4">Статус системы</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="flex items-center space-x-3" data-testid="status-telegram">
          <div className={`w-3 h-3 rounded-full ${getStatusColor(systemStatus?.telegram.status || 'error')}`}></div>
          <div>
            <p className="text-sm font-medium">Telegram Bot API</p>
            <p className="text-xs text-muted-foreground">
              {systemStatus?.telegram.message || 'Проверка статуса...'}
            </p>
          </div>
        </div>
        <div className="flex items-center space-x-3" data-testid="status-google-drive">
          <div className={`w-3 h-3 rounded-full ${getStatusColor(systemStatus?.googleDrive.status || 'error')}`}></div>
          <div>
            <p className="text-sm font-medium">Google Drive API</p>
            <p className="text-xs text-muted-foreground">
              {systemStatus?.googleDrive.message || 'Проверка статуса...'}
            </p>
          </div>
        </div>
        <div className="flex items-center space-x-3" data-testid="status-google-docs">
          <div className={`w-3 h-3 rounded-full ${getStatusColor(systemStatus?.googleDocs.status || 'error')}`}></div>
          <div>
            <p className="text-sm font-medium">Google Docs API</p>
            <p className="text-xs text-muted-foreground">
              {systemStatus?.googleDocs.message || 'Проверка статуса...'}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
