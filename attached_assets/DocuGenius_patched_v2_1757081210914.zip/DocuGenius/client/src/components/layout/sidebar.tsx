import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";

const menuItems = [
  { path: "/", label: "Дашборд", icon: "fas fa-chart-bar" },
  { path: "/users", label: "Пользователи", icon: "fas fa-users" },
  { path: "/templates", label: "Шаблоны", icon: "fas fa-file-contract" },
  { path: "/counterparties", label: "Контрагенты", icon: "fas fa-building" },
  { path: "/ai-config", label: "ИИ Конфигурация", icon: "fas fa-robot" },
  { path: "/integrations", label: "Интеграции", icon: "fas fa-puzzle-piece" },
  { path: "/google-drive", label: "Google Drive", icon: "fas fa-folder" },
  { path: "/settings", label: "Настройки", icon: "fas fa-cog" },
];

export function Sidebar() {
  const [location] = useLocation();

  return (
    <div className="w-64 bg-card border-r border-border flex flex-col">
      {/* Logo and Brand */}
      <div className="p-6 border-b border-border">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
            <i className="fas fa-file-alt text-primary-foreground text-sm"></i>
          </div>
          <div>
            <h1 className="text-lg font-semibold">DocuBot</h1>
            <p className="text-xs text-muted-foreground">Admin Panel</p>
          </div>
        </div>
      </div>
      
      {/* Navigation Menu */}
      <nav className="flex-1 p-4">
        <ul className="space-y-2">
          {menuItems.map((item) => {
            const isActive = location === item.path;
            return (
              <li key={item.path}>
                <Link href={item.path}>
                  <a className={cn(
                    "flex items-center space-x-3 px-3 py-2 rounded-lg text-sm font-medium transition-all duration-200",
                    isActive 
                      ? "bg-primary text-primary-foreground" 
                      : "text-muted-foreground hover:bg-muted hover:text-foreground"
                  )} data-testid={`sidebar-link-${item.path.replace("/", "") || "dashboard"}`}>
                    <i className={cn(item.icon, "w-4")}></i>
                    <span>{item.label}</span>
                  </a>
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>
      
      {/* User Profile */}
      <div className="p-4 border-t border-border">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-muted rounded-full flex items-center justify-center">
            <i className="fas fa-user text-muted-foreground text-sm"></i>
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium" data-testid="admin-name">Админ</p>
            <p className="text-xs text-muted-foreground truncate" data-testid="admin-email">admin@docubot.kz</p>
          </div>
          <button className="text-muted-foreground hover:text-foreground" data-testid="button-logout">
            <i className="fas fa-sign-out-alt text-sm"></i>
          </button>
        </div>
      </div>
    </div>
  );
}
