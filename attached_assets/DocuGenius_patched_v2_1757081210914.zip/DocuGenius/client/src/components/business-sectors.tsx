import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

interface BusinessSector {
  id: string;
  name: string;
  icon: string;
  userCount: number;
  isActive: boolean;
}

export function BusinessSectors() {
  const { data: sectors = [], isLoading } = useQuery<BusinessSector[]>({
    queryKey: ["/api/business-sectors"],
  });

  if (isLoading) {
    return (
      <div className="bg-card p-6 rounded-lg border border-border">
        <h2 className="text-lg font-semibold mb-4">Активные отрасли</h2>
        <div className="space-y-4">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="animate-pulse">
              <div className="flex items-center justify-between p-3">
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-muted rounded-lg"></div>
                  <div>
                    <div className="h-4 bg-muted rounded w-24 mb-2"></div>
                    <div className="h-3 bg-muted rounded w-20"></div>
                  </div>
                </div>
                <div className="w-20 h-6 bg-muted rounded"></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="bg-card p-6 rounded-lg border border-border">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold">Активные отрасли</h2>
        <Link href="/ai-config">
          <Button variant="ghost" size="sm" data-testid="link-configure-ai">
            Настроить ИИ
          </Button>
        </Link>
      </div>
      <div className="space-y-4">
        {sectors.length === 0 ? (
          <div className="text-center py-8">
            <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
              <i className="fas fa-industry text-muted-foreground text-xl"></i>
            </div>
            <p className="text-muted-foreground">Отрасли еще не настроены</p>
          </div>
        ) : (
          sectors.map((sector) => (
            <div 
              key={sector.id} 
              className="flex items-center justify-between p-3 hover:bg-muted rounded-lg transition-colors"
              data-testid={`sector-item-${sector.id}`}
            >
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center">
                  <i className={`${sector.icon} text-primary text-sm`}></i>
                </div>
                <div>
                  <p className="text-sm font-medium" data-testid={`sector-name-${sector.id}`}>
                    {sector.name}
                  </p>
                  <p className="text-xs text-muted-foreground" data-testid={`sector-users-${sector.id}`}>
                    {sector.userCount} пользователь{sector.userCount > 1 ? 'а' : ''}
                  </p>
                </div>
              </div>
              <div className="text-right">
                <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs ${
                  sector.isActive ? 'bg-accent/10 text-accent' : 'bg-muted text-muted-foreground'
                }`}>
                  {sector.isActive ? 'Настроено' : 'Требует настройки'}
                </span>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
