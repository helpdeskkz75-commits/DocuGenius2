import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/dashboard";
import Users from "@/pages/users";
import Templates from "@/pages/templates";
import Counterparties from "@/pages/counterparties";
import AIConfig from "@/pages/ai-config";
import Integrations from "@/pages/integrations";
import GoogleDrive from "@/pages/google-drive";
import Settings from "@/pages/settings";
import { Sidebar } from "@/components/layout/sidebar";

function Router() {
  return (
    <div className="flex min-h-screen">
      <Sidebar />
      <div className="flex-1">
        <Switch>
          <Route path="/" component={Dashboard} />
          <Route path="/users" component={Users} />
          <Route path="/templates" component={Templates} />
          <Route path="/counterparties" component={Counterparties} />
          <Route path="/ai-config" component={AIConfig} />
          <Route path="/integrations" component={Integrations} />
          <Route path="/google-drive" component={GoogleDrive} />
          <Route path="/settings" component={Settings} />
          <Route component={NotFound} />
        </Switch>
      </div>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
