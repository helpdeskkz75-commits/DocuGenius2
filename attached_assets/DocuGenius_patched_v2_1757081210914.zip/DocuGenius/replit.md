# Overview

This is a Telegram-based document management system that automates document generation for Kazakhstani businesses. The system provides an admin dashboard for managing users, templates, and integrations, while offering a Telegram bot interface for end users to create legal documents like contracts, invoices, and acts. The application focuses on serving different business sectors (dentistry, restaurants, construction, etc.) with sector-specific document templates stored in Google Drive.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
The client is built with React 18 using Vite as the build tool. The UI leverages shadcn/ui components with Radix UI primitives for a consistent design system. The application uses Wouter for client-side routing and TanStack Query for server state management. The styling is handled by Tailwind CSS with a custom design token system for theming.

## Backend Architecture
The server uses Express.js with TypeScript, following a modular service-oriented architecture. Key services include:
- **Telegram Bot Service**: Manages bot interactions and command handling
- **Document Generator**: Processes templates with user data to create documents  
- **Google Drive Service**: Handles file storage and folder management
- **Storage Layer**: Abstracts data access with interface-based design

The application uses a custom storage interface that can be implemented with different databases, though the current implementation appears to be in-memory or mock-based.

## Database Design
The schema defines several core entities using Drizzle ORM:
- **Users**: Stores Telegram user info, business details, and Google OAuth tokens
- **Templates**: Document templates with sector categorization and Google Docs integration
- **Counterparties**: Business partners/clients with tax and contact information
- **Documents**: Generated document records with status tracking
- **Business Sectors**: Categorization system for different industries
- **Bot Sessions**: Telegram conversation state management

## Authentication & Authorization
The system uses Telegram-based authentication where users are identified by their Telegram IDs. Google OAuth integration is implemented for accessing Google Drive services. The admin dashboard appears to have basic session-based authentication.

## Document Processing Workflow
1. Users initiate document creation via Telegram bot commands
2. Bot guides users through data collection for template placeholders
3. System processes templates by merging user/counterparty data with Google Docs templates
4. Generated documents are saved to organized Google Drive folder structures
5. Users receive links to completed documents via Telegram

## API Structure
The backend exposes RESTful endpoints for:
- Dashboard statistics and analytics
- User management (CRUD operations)
- Template management with sector filtering
- System settings and configuration
- Google Drive integration status

## Error Handling & Logging
The application implements centralized error handling with Express middleware. Request/response logging is built into the server with custom formatting for API endpoints. The system tracks response times and captures JSON responses for debugging.

## Development Setup
The project uses modern tooling with TypeScript throughout, ESBuild for production builds, and Vite's HMR for development. The monorepo structure shares types between client and server via a shared schema package.

# External Dependencies

## Database & ORM
- **PostgreSQL**: Primary database using Neon serverless hosting
- **Drizzle ORM**: Type-safe database queries and migrations
- **connect-pg-simple**: PostgreSQL session store integration

## Telegram Integration
- **node-telegram-bot-api**: Official Telegram Bot API wrapper for handling bot interactions, webhooks, and message processing

## Google Services
- **Google Drive API**: Document storage and folder management
- **Google Docs API**: Template processing and document generation
- **Google OAuth 2.0**: Authentication for accessing user's Google Drive

## Frontend Libraries
- **React Query (@tanstack/react-query)**: Server state management and caching
- **Radix UI**: Unstyled accessible UI primitives
- **shadcn/ui**: Pre-built component library built on Radix
- **React Hook Form**: Form validation and state management
- **Wouter**: Lightweight client-side routing

## Development Tools
- **Vite**: Build tool and development server
- **TypeScript**: Type safety across the entire stack
- **Tailwind CSS**: Utility-first CSS framework
- **ESBuild**: Fast JavaScript bundler for production
- **Drizzle Kit**: Database migration and schema management tools

## Hosting & Infrastructure
- **Replit**: Development and hosting platform
- **Neon Database**: Serverless PostgreSQL hosting
- **Google Cloud Platform**: For Google services integration