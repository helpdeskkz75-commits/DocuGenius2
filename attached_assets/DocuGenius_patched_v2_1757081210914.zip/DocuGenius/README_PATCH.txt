# DocuGenius MVP Patch (AI Assist)
Added:
- language detection + 3-step funnel (server/services/{langDetect,funnel}.ts)
- Google Sheets catalog & leads (server/integrations/google/sheets.ts)
- QR payment mock (server/services/qr.ts; routes for leads & callback)
- WhatsApp provider skeleton (server/integrations/whatsapp/*)
- New bot commands: /stop, /price, /find, /promo, /order

ENV to add:
  TELEGRAM_BOT_TOKEN=...
  TELEGRAM_OPERATORS_GROUP_ID=... # optional
  PRICES_SHEET_ID=...
  PRICES_RANGE=Sheet1!A:Z
  LEADS_SHEET_ID=...              # optional
  LEADS_RANGE=Sheet1!A:Z
  GOOGLE_CREDENTIALS_JSON_BASE64=...
  PROMO_URL=https://example.com
  PAYMENT_CALLBACK_SECRET=...
  WA_PROVIDER=360dialog
  WA_API_URL=https://waba.360dialog.io/v1
  WA_API_KEY=...
  WA_PHONE_NUMBER_ID=...

NPM:
  npm i googleapis qrcode

Additional ENV:
  TWO_GIS_URL=https://2gis.kz/astana/search/YourAddress
  CALLBACKS_SHEET_ID=<ID таблицы для перезвонов>
  CALLBACKS_RANGE=Sheet1!A:Z
